package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import fujdevelopers.com.jaaflongtandooricms.R;

public class MainActivity extends AppCompatActivity {


    public static int cat_number = 0;

    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        OnCliclListeners();


        mAuth = FirebaseAuth.getInstance();
        Log.d("Checking-----", " auth " + mAuth.getUid());


        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountType").child(mAuth.getCurrentUser().getUid());
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String type = dataSnapshot.getValue().toString();

                    if (type.equals("Worker")){
                        findViewById(R.id.add_category).setVisibility(View.GONE);
                        findViewById(R.id.edit_category).setVisibility(View.GONE);
                        findViewById(R.id.add_product).setVisibility(View.GONE);
                        findViewById(R.id.edit_product).setVisibility(View.GONE);
                        findViewById(R.id.add_coupon).setVisibility(View.GONE);
                        findViewById(R.id.edit_coupon).setVisibility(View.GONE);
                    }
                    OnCliclListeners();



                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



//        findViewById(R.id.add_offer).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(MainActivity.this, AddOfferActivity.class));
//            }
//        });
//
//        findViewById(R.id.remove_offer).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(MainActivity.this, RemoveOfferActivity.class));
//            }
//        });
//        findViewById(R.id.add_popup_offer).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(MainActivity.this, AddPoPOffer.class));
//            }
//        });
//
//        findViewById(R.id.remove_popup_offer).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(MainActivity.this, EditPoPOffer.class));
//            }
//        });
    }

    private void OnCliclListeners(){

        findViewById(R.id.add_category).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddCategory.class));
            }
        });

        findViewById(R.id.edit_category).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cat_number = 1;
                startActivity(new Intent(MainActivity.this, AllCategories.class));
            }
        });

        findViewById(R.id.subcategory).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SubActivity.class));
            }
        });


        findViewById(R.id.add_product).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddProduct.class));
            }
        });

        findViewById(R.id.edit_product).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cat_number  = 2;
                startActivity(new Intent(MainActivity.this, AllCategories.class));
            }
        });
        findViewById(R.id.reservation).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cat_number  = 2;
                startActivity(new Intent(MainActivity.this, Reservation.class));
            }
        });
        findViewById(R.id.add_coupon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddCoupon.class));
            }
        });
        findViewById(R.id.edit_coupon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AllCoupons.class));
            }
        });

        findViewById(R.id.new_orders).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, NewOrders.class));
            }
        });
        findViewById(R.id.notification).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Notification.class));
            }
        });
        findViewById(R.id.pending_orders).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PendingOrders.class));
            }
        });
        findViewById(R.id.completed_orders).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CompletedOrders.class));
            }
        });

        findViewById(R.id.rejected_order).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RejectedOrders.class));
            }
        });

        findViewById(R.id.register_user).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RegisteredUser.class));
            }
        });




        findViewById(R.id.change_password).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ChangePassword.class));
            }
        });
        findViewById(R.id.logout_admin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                startActivity(new Intent(MainActivity.this, LogInActivity.class));
                finish();
            }
        });



    }



}
