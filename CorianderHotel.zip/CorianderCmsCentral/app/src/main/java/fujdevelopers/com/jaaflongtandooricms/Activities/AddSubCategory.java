package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class AddSubCategory extends AppCompatActivity {

    EditText categoryName;
    TextView Category_Name_View;
    CircleImageView categoryImage;

    Button addCategoryBtn;

    Uri resultUri;
    String imgUrl;
    int picSelected = 0;

    ProgressDialog progressDialog;

    DatabaseReference mDatabaseForAddingCategory;
    String key;

    String Selected_Category_ID;
    String Selected_Category_Name;

    private ArrayList<String> Catagories_Names = new ArrayList<>();
    private ArrayList<String> Catagories_ID = new ArrayList<>();

    private Dialog Category_Select_Dialog;
    EditText Category_Search_Box;
    ListView Category_List_View;
    private ArrayAdapter<String> Category_Item_Adapter;


    private void Fetch_Categories() {
        String[] item = {""};
        Category_Item_Adapter = new ArrayAdapter<String>(AddSubCategory.this, R.layout.list_row, item);
        DatabaseReference Reference = FirebaseDatabase.getInstance().getReference().child("Categories");
        Reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot Child : dataSnapshot.getChildren()) {
                    Catagories_ID.add(Child.child("catId").getValue().toString());
                    Catagories_Names.add(Child.child("catName").getValue().toString());
                }
                Category_Item_Adapter = new ArrayAdapter<String>(AddSubCategory.this, R.layout.list_row, Catagories_Names);
                Category_List_View.setAdapter(Category_Item_Adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void Category_Select() {
        Category_Select_Dialog = new Dialog(this);
        Category_Select_Dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        Category_Select_Dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Category_Select_Dialog.setContentView(R.layout.select_layout);
        Category_Select_Dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        Category_Select_Dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        Category_Select_Dialog.setCancelable(true);
        Category_Search_Box = Category_Select_Dialog.findViewById(R.id.Search_Data_Edit);
        Category_List_View = Category_Select_Dialog.findViewById(R.id.List_View_Id);
//        String[] item = {"1"};
//        Category_Item_Adapter = new ArrayAdapter<String>(AddProduct.this, R.layout.list_row, item);
        Category_List_View.setAdapter(Category_Item_Adapter);
        Category_List_View.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Category_Select_Dialog.dismiss();
                String selectedFromList = (Category_List_View.getItemAtPosition(i)).toString();
                Category_Name_View.setText(selectedFromList);
                Selected_Category_ID = Catagories_ID.get(i);
                Selected_Category_Name = selectedFromList;
            }
        });

        Category_Search_Box.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Call back the Adapter with current character to Filter
                Category_Item_Adapter.getFilter().filter(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subcategory);

        Fetch_Categories();

        Category_Select();

        Category_Name_View = findViewById(R.id.Category_View_Id);

        Category_Name_View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Category_Select_Dialog.show();
            }
        });

        progressDialog = new ProgressDialog(this);

        categoryName = findViewById(R.id.category_name_edit_add);
        categoryImage = findViewById(R.id.category_image);
        categoryImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.activity()
                        .start(AddSubCategory.this);
            }
        });


        addCategoryBtn = findViewById(R.id.add_Category_btn);
        addCategoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (categoryName.getText().toString().isEmpty()){
                    categoryName.setError("Please Enter Sub-Category Name First.");
                    return;
                }

                if (picSelected == 0){
                    MDToast.makeText(AddSubCategory.this, "Please Add Image First.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                mDatabaseForAddingCategory = FirebaseDatabase.getInstance().getReference().child("Categories").child(Selected_Category_ID).child("Subcat");
                key = mDatabaseForAddingCategory.push().getKey();

                uploadImageFirst();
                //uploadDataToDatabase();

            }
        });

    }
    private void uploadImageFirst(){

        progressDialog.setTitle("Uploading Image");
        progressDialog.setMessage("Please Wait while we upload the category to database.");
        progressDialog.show();

        final StorageReference Submit_Datareference = FirebaseStorage.getInstance().getReference("CategoryImages").child(key);
        Submit_Datareference.putFile(resultUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Submit_Datareference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        //imagesUrl.add(uri.toString());

                        imgUrl = uri.toString();

                        uploadDataToDatabase();

                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                //Dialog.Set_Percetage((int) progress);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(AddSubCategory.this, "Error!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });

    }

    private void uploadDataToDatabase(){

        Log.d("UPLOADSUBCAT","catid: "+Selected_Category_ID+" "+key);

        CatModel catModel = new CatModel(categoryName.getText().toString(),imgUrl,Selected_Category_ID,key);
//   "https://firebasestorage.googleapis.com/v0/b/jaaflongtandoori-690f7.appspot.com/o/menuImages%2FCHICKEN%20OR%20LAMB%20TIKKA-min.jpg?alt=media&token=6dccb1c2-094f-4025-9e7b-8d05295142c9"
        mDatabaseForAddingCategory.child(key).setValue(catModel)
                .addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                MDToast.makeText(AddSubCategory.this, "Sub-Category Uploaded Successfully.", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                finish();
            }


        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                MDToast.makeText(AddSubCategory.this, "Sub-Category Upload FAILED. "+e.toString(), MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                finish();

            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                resultUri = result.getUri();

                picSelected = 1;

                Glide.with(AddSubCategory.this).load(resultUri).into(categoryImage);



            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();

                Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

}
