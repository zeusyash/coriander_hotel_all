package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wang.avi.AVLoadingIndicatorView;

import java.util.ArrayList;
import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Adapter.ProductAdapter;
import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.Model.ProductModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class AllProducts extends AppCompatActivity {



    RecyclerView productsRecycler;
    ProductAdapter adapter;

    CatModel catModel;

    DatabaseReference mDatabaseForGettingProducts;

    List<ProductModel> list = new ArrayList<>();

    AVLoadingIndicatorView avi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_products);

        catModel = (CatModel) getIntent().getSerializableExtra("Category");

        initViews();

    }


    private void initViews(){
        avi = findViewById(R.id.avi_all_product);
        productsRecycler = findViewById(R.id.products_recycler);
        adapter = new ProductAdapter(list, this);
        productsRecycler.setAdapter(adapter);
        productsRecycler.setLayoutManager(new GridLayoutManager(this,2));
        getData();
    }

    private void getData(){
        mDatabaseForGettingProducts = FirebaseDatabase.getInstance().getReference().child("Categories").child(catModel.getCatId()).child("Products");
        mDatabaseForGettingProducts.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();

                for (DataSnapshot d: dataSnapshot.getChildren()){

                    ProductModel productModel = d.getValue(ProductModel.class);
//                    String productName = d.child("ProductName").getValue().toString();
//                    String productId = d.child("ProductId").getValue().toString();
//                    String productImage = d.child("ProductImage").getValue().toString();
//                    String productDisc = d.child("ProductDisc").getValue().toString();
//                    String productPrice = d.child("ProductPrice").getValue().toString();
//                    String catId = d.child("CategoryId").getValue().toString();
//                    String catName = d.child("CategoryName").getValue().toString();

//                    list.add(new ProductModel(catId, catName, productId, productName, productImage, productDisc, productPrice));

                    Log.d("Checking___","Pro_Image " + productModel.getProductImage());

                    list.add(productModel);

                }
                Log.d("Checking___","List_Size " + list.size());

                avi.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
