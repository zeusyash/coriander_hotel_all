package fujdevelopers.com.jaaflongtandooricms.Adapter;


import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.UserModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.UsersAdapter_Holder> {
    Context context;
    List<UserModel> list;

    public UsersAdapter(Context context, List<UserModel> list) {
        this.context = context;
        this.list = list;

    }

    @NonNull
    @Override
    public UsersAdapter.UsersAdapter_Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.useradapter_view, viewGroup, false);
        return new UsersAdapter_Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final UsersAdapter.UsersAdapter_Holder holder, final int position) {

        final UserModel model = list.get(position);
        holder.Sub_name_View.setText(model.getUser_name());

        Glide.with(context).load(model.getUser_image()).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                Log.d("Called", "Called  Not-------");
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                holder.P_Bar.setVisibility(View.GONE);
                Log.d("Called", "Called -------");
                return false;
            }
        }).into(holder.Grid_Item);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public class UsersAdapter_Holder extends RecyclerView.ViewHolder {

        CircleImageView Grid_Item;
        ProgressBar P_Bar;
        TextView Sub_name_View;

        public UsersAdapter_Holder(@NonNull View v) {
            super(v);



            Grid_Item = v.findViewById(R.id.user_image);
            P_Bar = v.findViewById(R.id.avi);
            Sub_name_View = v.findViewById(R.id.Sub_Cat_Name_Id);



        }
    }
}
