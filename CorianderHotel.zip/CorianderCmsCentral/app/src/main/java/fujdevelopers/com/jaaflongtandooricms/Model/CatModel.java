package fujdevelopers.com.jaaflongtandooricms.Model;

import java.io.Serializable;

public class CatModel implements Serializable {

    private String catName;
    private String catImage;
    private String catId;

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    private String sid;

    public CatModel(String catName, String catImage, String catId) {
        this.catName = catName;
        this.catImage = catImage;
        this.catId = catId;
    }

 public CatModel(String catName, String catImage, String catId,String sid) {
        this.catName = catName;
        this.catImage = catImage;
        this.catId = catId;
        this.sid = sid;
    }

    public CatModel() {
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getCatImage() {
        return catImage;
    }

    public void setCatImage(String catImage) {
        this.catImage = catImage;
    }

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }
}
