package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.IOException;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class AddCategory extends AppCompatActivity {

    EditText categoryName;
    CircleImageView categoryImage;

    Button addCategoryBtn;

    Uri resultUri;
    String imgUrl;
    int picSelected = 0;

    ProgressDialog progressDialog;

    DatabaseReference mDatabaseForAddingCategory;
    String key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);


        progressDialog = new ProgressDialog(this);

        categoryName = findViewById(R.id.category_name_edit_add);
        categoryImage = findViewById(R.id.category_image);
        categoryImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.activity()
                        .start(AddCategory.this);
            }
        });


        addCategoryBtn = findViewById(R.id.add_Category_btn);
        addCategoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (categoryName.getText().toString().isEmpty()){
                    categoryName.setError("Please Enter Category Name First.");
                    return;
                }

                if (picSelected == 0){
                    MDToast.makeText(AddCategory.this, "Please Add Image First.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                mDatabaseForAddingCategory = FirebaseDatabase.getInstance().getReference().child("Categories");
                key = mDatabaseForAddingCategory.push().getKey();

                uploadImageFirst();

            }
        });

    }
    private void uploadImageFirst(){

        progressDialog.setTitle("Uploading Image");
        progressDialog.setMessage("Please Wait while we upload the category to database.");
        progressDialog.show();

        final StorageReference Submit_Datareference = FirebaseStorage.getInstance().getReference("CategoryImages").child(key);
        Submit_Datareference.putFile(resultUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Submit_Datareference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        //imagesUrl.add(uri.toString());

                        imgUrl = uri.toString();

                        uploadDataToDatabase();

                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                //Dialog.Set_Percetage((int) progress);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(AddCategory.this, "Error!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });

    }

    private void uploadDataToDatabase(){


        CatModel catModel = new CatModel(categoryName.getText().toString(),imgUrl,key);

        mDatabaseForAddingCategory.child(key).setValue(catModel).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                MDToast.makeText(AddCategory.this, "Category Uploaded Successfully.", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                finish();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                resultUri = result.getUri();

                picSelected = 1;

                Glide.with(AddCategory.this).load(resultUri).into(categoryImage);



            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();

                Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

}
