package fujdevelopers.com.jaaflongtandooricms.Model;

import java.io.Serializable;

public class ReservationModel implements Serializable {

    String name;
    String email;
    String phno;
    String date;
    String nop;
    String note;
    String time_slot;
    String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhno() {
        return phno;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNop() {
        return nop;
    }

    public void setNop(String nop) {
        this.nop = nop;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getTime_slot() {
        return time_slot;
    }

    public void setTime_slot(String time_slot) {
        this.time_slot = time_slot;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    String type;

    public ReservationModel(String id,String name, String email, String phno, String date, String nop, String note, String time_slot, String status, String type) {

        this.id = id;
        this.name = name;
        this.email = email;
        this.phno = phno;
        this.date = date;
        this.nop = nop;
        this.note = note;
        this.time_slot = time_slot;
        this.status = status;
        this.type = type;
    }

}
