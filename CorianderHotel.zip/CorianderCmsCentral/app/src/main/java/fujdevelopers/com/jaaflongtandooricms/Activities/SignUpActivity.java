package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.util.HashMap;

import fujdevelopers.com.jaaflongtandooricms.R;

public class SignUpActivity extends AppCompatActivity {


    EditText emailEdit, paswordEdit, nameEdit;
    Button registerBtn;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;
//    private CircleImageView Register_image;
//    private Uri Image_uri;
//    private StorageReference storageReference;
//    private DatabaseReference databaseReference;
//    private String Key, Registe_name, Register_email,Register_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);


        emailEdit = findViewById(R.id.email_edit_register);
        paswordEdit = findViewById(R.id.password_edit_register);
        nameEdit = findViewById(R.id.name_edit_register);
//        Register_image = findViewById(R.id.user_image);


        registerBtn = findViewById(R.id.register_btn_register);

//        getting_userImage();


        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                if(Image_uri==null)
//                {
//                    MDToast.makeText(SignUpActivity.this,"Select an Image",MDToast.TYPE_ERROR,MDToast.LENGTH_LONG).show();
//                    return;
//
//                }

                if (emailEdit.getText().toString().isEmpty() || paswordEdit.getText().toString().isEmpty() || nameEdit.getText().toString().isEmpty()) {
                    MDToast.makeText(SignUpActivity.this, "Please fill all the fields above first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (!isEmailvalid(emailEdit.getText().toString())) {
                    MDToast.makeText(SignUpActivity.this, "Email is not valid", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                progressDialog.setTitle("Registering your account");
                progressDialog.setMessage("Please while we register your account");
                progressDialog.show();

                mAuth.createUserWithEmailAndPassword(emailEdit.getText().toString().trim(), paswordEdit.getText().toString())
                        .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("LOGGINGIN", "createUserWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    FirebaseMessaging.getInstance().subscribeToTopic("admina");

                                    updateUI();
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w("LOGGINGIN", "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(SignUpActivity.this, "Authentication failed : " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }

                                // ...
                            }
                        });
            }
        });


    }


    private void updateUI() {

        final HashMap Data = new HashMap();
        Data.put("Email", emailEdit.getText().toString().trim());
        Data.put("Name", nameEdit.getText().toString());

        DatabaseReference mDatabaseForInstance = FirebaseDatabase.getInstance().getReference().child("AccountType");
        mDatabaseForInstance.child(mAuth.getCurrentUser().getUid()).setValue("Admin").addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo");
                mDatabaseForManagement.child("Admin").child(mAuth.getCurrentUser().getUid()).updateChildren(Data).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        MDToast.makeText(SignUpActivity.this, "Successfully Registered As Admin", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                        startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                        finish();
                    }
                });
            }
        });


    }

    private boolean isEmailvalid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

//    private void getting_userImage() {
//        Register_image.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//                ask_for_image();
//            }
//        });
//    }
//    public void ask_for_image() {
//        CropImage.activity()
//                .setAspectRatio(1, 1).start(SignUpActivity.this);
//
//    }

//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        final CropImage.ActivityResult result = CropImage.getActivityResult(data);
//        if (resultCode == RESULT_OK) {
//            Image_uri = result.getUri();
//
//            Glide.with(SignUpActivity.this).load(Image_uri).into(Register_image);
//        }
//
//    }
}
