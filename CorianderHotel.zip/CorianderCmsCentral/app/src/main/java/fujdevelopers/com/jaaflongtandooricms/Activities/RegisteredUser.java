package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Adapter.PendingOrderAdapter;
import fujdevelopers.com.jaaflongtandooricms.Adapter.UsersAdapter;
import fujdevelopers.com.jaaflongtandooricms.Model.PendingOrderModel;
import fujdevelopers.com.jaaflongtandooricms.Model.UserModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class RegisteredUser extends AppCompatActivity {


    RecyclerView pendingRecycler;
    UsersAdapter adapter;
    List<UserModel> list = new ArrayList<>();
    long curr;
    Calendar calendar, cal;
    String tdate, odate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered_user);

        pendingRecycler = findViewById(R.id.pending_recycler);
        adapter = new UsersAdapter(this, list);
        pendingRecycler.setAdapter(adapter);
        pendingRecycler.setLayoutManager(new LinearLayoutManager(this));
        calendar = Calendar.getInstance();
        cal = Calendar.getInstance();
        getData();
    }
    private void getData() {


        DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users");
        mDatabaseForManagement.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();

                for (DataSnapshot d : dataSnapshot.getChildren()) {

                    try {

                        UserModel userModel = d.getValue(UserModel.class);
                        list.add(userModel);

                    } catch (Exception e) {
                        e.printStackTrace();

                        Log.v("errorrrrr__", "Error: " + e.getMessage());
                    }
                }

                adapter.notifyDataSetChanged();

                if (list.size() == 0) {
                    findViewById(R.id.noOrdersText).setVisibility(View.VISIBLE);
                } else {
                    findViewById(R.id.noOrdersText).setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
