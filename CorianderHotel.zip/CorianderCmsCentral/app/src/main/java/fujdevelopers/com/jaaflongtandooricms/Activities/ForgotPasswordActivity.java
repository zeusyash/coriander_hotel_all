package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.valdesekamdem.library.mdtoast.MDToast;

import fujdevelopers.com.jaaflongtandooricms.R;


public class ForgotPasswordActivity extends AppCompatActivity {

    EditText emailEdit;

    Button sendBtn;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);


        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);

        emailEdit = findViewById(R.id.email_edit_login);

        sendBtn = findViewById(R.id.send);


        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emailEdit.getText().toString().isEmpty()) {
                    MDToast.makeText(ForgotPasswordActivity.this, "Please Enter Email.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (!isEmailvalid(emailEdit.getText().toString())) {
                    MDToast.makeText(ForgotPasswordActivity.this, "Email not Valid", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                progressDialog.setTitle("Sending Mail");
                progressDialog.setMessage("Please wait while we send email.");
                progressDialog.show();

                FirebaseAuth auth = FirebaseAuth.getInstance();
                String emailAddress = emailEdit.getText().toString();

                auth.sendPasswordResetEmail(emailAddress)
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressDialog.dismiss();
//                                Toast.makeText(ForgotPasswordActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();
                                Toast.makeText(ForgotPasswordActivity.this,"This email was not registered",Toast.LENGTH_LONG).show();
/*
                                Log.d("FORGOTPASS:",e.toString());
                                Log.d("FORGOTPASS:",e.getLocalizedMessage().toString());
                                Log.d("FORGOTPASS:",e.getMessage().toString());
*/
                            }
                        })
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    progressDialog.dismiss();
                                    Toast.makeText(ForgotPasswordActivity.this,"Email sent!",Toast.LENGTH_SHORT).show();
                                    Log.d("FORGOTPASS", "Email sent.");
                                }
                            }
                        });

            }
        });

    }

    private boolean isEmailvalid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

}
