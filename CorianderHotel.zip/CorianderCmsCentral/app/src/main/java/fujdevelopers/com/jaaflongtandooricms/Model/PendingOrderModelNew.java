package fujdevelopers.com.jaaflongtandooricms.Model;

import java.io.Serializable;

public class PendingOrderModelNew implements Serializable {

    private String bookerName;
    private String bookerId;
    private String address;
    private String numberoffoods;

    public String getPhno() {
        return phno;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }

    private String phno;
    private String status;
    private String totalCost;
    private String orderDetails;
    private String ordertime;
    private String orderId;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    private String email;

    public String getAllergies() {
        return allergies;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }

    private String allergies;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    private String type;

    public PendingOrderModelNew() {
    }

    public PendingOrderModelNew(String phno, String bookerName, String bookerId, String address, String numberoffoods, String status, String totalCost, String orderDetails, String ordertime, String orderId, String allergies, String type,String email) {
        this.bookerName = bookerName;
        this.bookerId = bookerId;
        this.address = address;
        this.numberoffoods = numberoffoods;
        this.status = status;
        this.totalCost = totalCost;
        this.orderDetails = orderDetails;
        this.ordertime = ordertime;
        this.orderId = orderId;
        this.allergies = allergies;
        this.type = type;
        this.phno = phno;
        this.email = email;
    }

    public String getBookerName() {
        return bookerName;
    }

    public void setBookerName(String bookerName) {
        this.bookerName = bookerName;
    }

    public String getBookerId() {
        return bookerId;
    }

    public void setBookerId(String bookerId) {
        this.bookerId = bookerId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNumberoffoods() {
        return numberoffoods;
    }

    public void setNumberoffoods(String numberoffoods) {
        this.numberoffoods = numberoffoods;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(String totalCost) {
        this.totalCost = totalCost;
    }

    public String getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(String orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        this.ordertime = ordertime;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
