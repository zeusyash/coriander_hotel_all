package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Adapter.PendingOrderAdapter;
import fujdevelopers.com.jaaflongtandooricms.Adapter.PendingOrderAdapterNew;
import fujdevelopers.com.jaaflongtandooricms.Model.PendingOrderModel;
import fujdevelopers.com.jaaflongtandooricms.Model.PendingOrderModelNew;
import fujdevelopers.com.jaaflongtandooricms.R;

public class PendingOrders extends AppCompatActivity {


    RecyclerView pendingRecycler;
    PendingOrderAdapterNew adapter;
    List<PendingOrderModelNew> list = new ArrayList<>();
    long curr;
    Calendar calendar, cal;
    String tdate, odate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_orders);

        pendingRecycler = findViewById(R.id.pending_recycler);
        adapter = new PendingOrderAdapterNew(list, this);
        pendingRecycler.setAdapter(adapter);
        pendingRecycler.setLayoutManager(new LinearLayoutManager(this));
        calendar = Calendar.getInstance();
        cal = Calendar.getInstance();
        getData();

    }

    private void getData() {


        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Orders");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();

                for (DataSnapshot d : dataSnapshot.getChildren()) {

                    try {
                        String name = d.child("Name").getValue().toString();
                        String address = d.child("Address").getValue().toString();
                        String phno = d.child("phno").getValue().toString();
                        String totalCost = d.child("TotalCost").getValue().toString();
                        String allergies = d.child("Allergies").getValue().toString();
                        String restaurant = d.child("Restaurant").getValue().toString();
                        String type = d.child("Type").getValue().toString();
                        String numberOfFoods = String.valueOf(d.child("NumberOfFoods").getValue(Integer.class));
                        String orderId = d.child("OrderId").getValue().toString();
                        String status = d.child("Status").getValue().toString();
                        String bookerId = d.child("UserId").getValue().toString();
                        String email=" ";
                        try{
                            email = d.child("email").getValue().toString();
                            Log.d("EMAILLOGS",email);
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }


                        String detail = "";
                        int number = Integer.parseInt(numberOfFoods);
                        for (int i = 0; i < number; i++) {
                            int quantity = d.child(String.valueOf(i)).child("quantity").getValue(Integer.class);
                            double price = Double.parseDouble(d.child(String.valueOf(i)).child("productPrice").getValue().toString());
                            double total = quantity * price;

                            String formattedValue = String.format("%.2f", total);

                            try{

                                if(!d.child(String.valueOf(i)).child("shortdescr").getValue().toString().equals(" ")){
                                    detail = detail + d.child(String.valueOf(i)).child("productName").getValue().toString() + "\n( " +d.child(String.valueOf(i)).child("shortdescr").getValue().toString() + " )\n   Price : " + d.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + d.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                }
                                else{
                                    detail = detail + d.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + d.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + d.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                }

                            }
                            catch (Exception e){
                                detail = detail + d.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + d.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + d.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                            }


                            String time = d.child("Order_Time").getValue().toString();

                            cal.setTimeInMillis(Long.parseLong(time));
                            odate = cal.get(Calendar.DAY_OF_MONTH) + ":" + cal.get(Calendar.MONTH) + ":" + cal.get(Calendar.YEAR);



                        }
                        if (status.equals("Pending") && restaurant.equals("Coriander Central Chorlton")) {
                            list.add(new PendingOrderModelNew(phno,name, bookerId, address, numberOfFoods, status, totalCost, detail, odate, orderId,allergies,type,email));

                        }

                    } catch (Exception e) {
                        e.printStackTrace();

                        Log.v("errorrrrr__", "Error: " + e.getMessage());
                    }
                }

                adapter.notifyDataSetChanged();

                if (list.size() == 0) {
                    findViewById(R.id.noOrdersText).setVisibility(View.VISIBLE);
                } else {
                    findViewById(R.id.noOrdersText).setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
