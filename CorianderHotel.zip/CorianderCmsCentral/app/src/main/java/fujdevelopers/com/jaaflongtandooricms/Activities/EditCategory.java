package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.IOException;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class EditCategory extends AppCompatActivity {

    CatModel model;

    EditText catName;
    CircleImageView catImage;
    Button updateCat, DeleteCategoryBtn;

    Uri resultUri;
    int picSelected = 0;

    ProgressDialog progressDialog;

    DatabaseReference mDatabaseForAddingCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_category);

        progressDialog = new ProgressDialog(this);

        model = (CatModel) getIntent().getSerializableExtra("Category");

        catImage = findViewById(R.id.category_image_edit);
        Glide.with(this).load(model.getCatImage()).into(catImage);

        catImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.activity()
                        .setAspectRatio(1, 1)
                        .start(EditCategory.this);
            }
        });
        catName = findViewById(R.id.category_name_edit_edit);
        catName.setText(model.getCatName());

        updateCat = findViewById(R.id.edit_Category_btn);
        DeleteCategoryBtn = findViewById(R.id.delete_Category_btn);


        progressDialog = new ProgressDialog(this);

        model = (CatModel) getIntent().getSerializableExtra("Category");

        catImage = findViewById(R.id.category_image_edit);
        Glide.with(this).load(model.getCatImage()).into(catImage);

        catImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.activity()
                        .setAspectRatio(1, 1)
                        .start(EditCategory.this);
            }
        });
        catName = findViewById(R.id.category_name_edit_edit);
        catName.setText(model.getCatName());

        updateCat = findViewById(R.id.edit_Category_btn);
        DeleteCategoryBtn = findViewById(R.id.delete_Category_btn);

        updateCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (catName.getText().toString().isEmpty()){
                    catName.setError("Please Enter a name First");
                    return;
                }

                mDatabaseForAddingCategory = FirebaseDatabase.getInstance().getReference().child("Categories");

                if (picSelected == 1){
                    uploadImageFirst();
                } else {
                    uploadDataToDatabase();
                }

                progressDialog.setTitle("Uploading");
                progressDialog.setMessage("Please Wait");
                progressDialog.show();
            }
        });

        DeleteCategoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(EditCategory.this);
                builder.setMessage("Do you really want to delete this category?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        DatabaseReference mDatabaseForDeleting = FirebaseDatabase.getInstance().getReference().child("Categories");
                        mDatabaseForDeleting.child(model.getCatId()).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                dialog.dismiss();
                                finish();
                            }
                        });
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();
            }
        });


    }


    private void uploadImageFirst(){

        progressDialog.setTitle("Uploading Image");
        progressDialog.setMessage("Please Wait while we upload new image.");

        final StorageReference Submit_Datareference = FirebaseStorage.getInstance().getReference("CategoryImages").child(model.getCatId());
        Submit_Datareference.putFile(resultUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Submit_Datareference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        //imagesUrl.add(uri.toString());

                        model.setCatImage(uri.toString());

                        uploadDataToDatabase();

                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                //Dialog.Set_Percetage((int) progress);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(EditCategory.this, "Error!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });

    }

    private void uploadDataToDatabase(){

        progressDialog.setTitle("Uploading Data");
        progressDialog.setMessage("Please Wait while we upload the new Data");

        HashMap Data = new HashMap();
        Data.put("catId", model.getCatId());
        Data.put("catName", catName.getText().toString());
        Data.put("catImage", model.getCatImage());


        mDatabaseForAddingCategory.child(model.getCatId()).updateChildren(Data).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                MDToast.makeText(EditCategory.this, "Category Edited Successfully.", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                resultUri = result.getUri();

                picSelected = 1;

       Glide.with(EditCategory.this).load(resultUri).into(catImage);


            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();

                Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
