package fujdevelopers.com.jaaflongtandooricms.Model;

import java.io.Serializable;

public class CouponModel implements Serializable {

    private String coupon_number,coupon_amount,coupon_key;

    public CouponModel() {
    }

    public CouponModel(String coupon_number, String coupon_amount, String coupon_key) {
        this.coupon_number = coupon_number;
        this.coupon_amount = coupon_amount;
        this.coupon_key = coupon_key;
    }

    public String getCoupon_number() {
        return coupon_number;
    }

    public void setCoupon_number(String coupon_number) {
        this.coupon_number = coupon_number;
    }

    public String getCoupon_amount() {
        return coupon_amount;
    }

    public void setCoupon_amount(String coupon_amount) {
        this.coupon_amount = coupon_amount;
    }

    public String getCoupon_key() {
        return coupon_key;
    }

    public void setCoupon_key(String coupon_key) {
        this.coupon_key = coupon_key;
    }
}
