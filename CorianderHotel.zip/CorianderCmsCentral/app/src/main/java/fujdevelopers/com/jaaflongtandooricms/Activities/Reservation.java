package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Adapter.PendingOrderAdapter;
import fujdevelopers.com.jaaflongtandooricms.Adapter.ReservationAdapter;
import fujdevelopers.com.jaaflongtandooricms.Model.PendingOrderModel;
import fujdevelopers.com.jaaflongtandooricms.Model.ReservationModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class Reservation extends AppCompatActivity {


    RecyclerView pendingRecycler;
    ReservationAdapter adapter;
    List<ReservationModel> list = new ArrayList<>();
    long curr;
    Calendar calendar, cal;
    String tdate, odate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        pendingRecycler = findViewById(R.id.pending_recycler);
        adapter = new ReservationAdapter(list, this);
        pendingRecycler.setAdapter(adapter);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(Reservation.this);
        mLayoutManager.setReverseLayout(true);
        mLayoutManager.setStackFromEnd(true);
        pendingRecycler.setLayoutManager(mLayoutManager);


//        pendingRecycler.setLayoutManager(new LinearLayoutManager(this));
        calendar = Calendar.getInstance();
        cal = Calendar.getInstance();
        getData();

    }

    private void getData() {


        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Reservation");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();

                for (DataSnapshot d : dataSnapshot.getChildren()) {

                    try {
                        String name = d.child("Name").getValue().toString();
                        String email = d.child("Email").getValue().toString();
                        String phno = d.child("Phone").getValue().toString();
                        String date = d.child("Date").getValue().toString();
                        String note = d.child("Note").getValue().toString();
                        String restaurant = d.child("Restaurant").getValue().toString();
                        String type = d.child("Type").getValue().toString();
                        String time_slot = d.child("Time_Slot").getValue().toString();
                        String nop = d.child("NOP").getValue().toString();
                        String id = String.valueOf(d.child("Id").getValue(Integer.class));
                        String status = d.child("Status").getValue().toString();

                        if (restaurant.equals("Coriander Central Chorlton")) {
                            list.add(new ReservationModel(id,name,email,phno,date,nop,note,time_slot,status,type));
                        }

                    } catch (Exception e) {
                        e.printStackTrace();

                        Log.v("errorrrrr__", "Error: " + e.getMessage());
                    }
                }

                adapter.notifyDataSetChanged();

                if (list.size() == 0) {
                    findViewById(R.id.noOrdersText).setVisibility(View.VISIBLE);
                } else {
                    findViewById(R.id.noOrdersText).setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
