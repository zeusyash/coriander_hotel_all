package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import fujdevelopers.com.jaaflongtandooricms.R;

public class SubActivity extends AppCompatActivity {


    public static int cat_number = 0;

    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);


        OnCliclListeners();


        mAuth = FirebaseAuth.getInstance();
        Log.d("Checking-----", " auth " + mAuth.getUid());


        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountType").child(mAuth.getCurrentUser().getUid());
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String type = dataSnapshot.getValue().toString();

                    if (type.equals("Worker")){
                        findViewById(R.id.add_category).setVisibility(View.GONE);
                        findViewById(R.id.edit_category).setVisibility(View.GONE);
                        findViewById(R.id.add_product).setVisibility(View.GONE);
                        findViewById(R.id.edit_product).setVisibility(View.GONE);
                    }
                    OnCliclListeners();



                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }

    private void OnCliclListeners(){

        findViewById(R.id.add_subcategory).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SubActivity.this, AddSubCategory.class));
            }
        });

        findViewById(R.id.edit_subcategory).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cat_number = 1;
                startActivity(new Intent(SubActivity.this, AllSubCategories.class));
            }
        });

        findViewById(R.id.add_subproduct).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SubActivity.this, AddSubProduct.class));
            }
        });

        findViewById(R.id.edit_subproduct).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cat_number  = 2;
                startActivity(new Intent(SubActivity.this, AllSubCategories.class));
            }
        });


    }



}
