package fujdevelopers.com.jaaflongtandooricms.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Activities.AllProducts;
import fujdevelopers.com.jaaflongtandooricms.Activities.EditCategory;
import fujdevelopers.com.jaaflongtandooricms.Activities.EditCoupon;
import fujdevelopers.com.jaaflongtandooricms.Activities.MainActivity;
import fujdevelopers.com.jaaflongtandooricms.Model.CouponModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class CouponAdapter extends RecyclerView.Adapter<CouponAdapter.ViewHolder> {

    List<CouponModel> list;
    Context context;

    public CouponAdapter(List<CouponModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public CouponAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.coupon_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CouponAdapter.ViewHolder holder, int position) {

        final CouponModel model = list.get(position);

        holder.counponnumber.setText(model.getCoupon_number());

        holder.couponamount.setText(model.getCoupon_amount());

        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    context.startActivity(new Intent(context, EditCoupon.class).putExtra("Coupon", model));

            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView counponnumber, couponamount;

        CardView bgCard;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            counponnumber = itemView.findViewById(R.id.couponno);
            couponamount = itemView.findViewById(R.id.couponamount);

            bgCard = itemView.findViewById(R.id.cat_bg_card);
        }
    }
}
