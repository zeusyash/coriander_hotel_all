package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.util.HashMap;

import fujdevelopers.com.jaaflongtandooricms.R;

public class AddCoupon extends AppCompatActivity {

    EditText couponnoEdit, couponamountEdit;

    Button addcoupon;

    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_coupon);

        progressDialog = new ProgressDialog(this);

        addcoupon = findViewById(R.id.addcoupon);
        couponnoEdit = findViewById(R.id.coupon_number);
        couponamountEdit = findViewById(R.id.coupon_amount);



        addcoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (couponnoEdit.getText().toString().isEmpty() || couponamountEdit.getText().toString().isEmpty()) {
                    MDToast.makeText(AddCoupon.this, "Please Fill above fields first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                progressDialog.setTitle("Adding Coupon");
                progressDialog.setMessage("Please wait while we add coupon no");
                progressDialog.show();

                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Coupons");
                String key = mDatabase.push().getKey();
                HashMap hashMap = new HashMap();
                hashMap.put("coupon_number", couponnoEdit.getText().toString());
                hashMap.put("coupon_amount", String.valueOf(couponamountEdit.getText().toString()));
                hashMap.put("coupon_key", key);


                mDatabase.child(key).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        Toast.makeText(AddCoupon.this, "Coupon Added", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AddCoupon.this, MainActivity.class));
                        finish();
                    }
                });


            }
        });


    }
}
