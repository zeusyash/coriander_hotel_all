package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.util.HashMap;

import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.Model.CouponModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class EditCoupon extends AppCompatActivity {

    EditText couponnoEdit, couponamountEdit;

    Button editcoupon,deletecoupon;

    ProgressDialog progressDialog;
    CouponModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_coupon);



        progressDialog = new ProgressDialog(this);
        model = (CouponModel) getIntent().getSerializableExtra("Coupon");

        editcoupon = findViewById(R.id.editcoupon);
        couponnoEdit = findViewById(R.id.coupon_number);
        couponnoEdit.setText(model.getCoupon_number());
        couponamountEdit = findViewById(R.id.coupon_amount);
        couponamountEdit.setText(model.getCoupon_amount());
        deletecoupon = findViewById(R.id.delete_coupon_btn);


        deletecoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Coupons").child(model.getCoupon_key());
                mDatabase.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(EditCoupon.this, "Coupon Deleted", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(EditCoupon.this, AllCoupons.class));
                        finish();
                    }
                });


            }
        });



        editcoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (couponamountEdit.getText().toString().isEmpty()) {
                    MDToast.makeText(EditCoupon.this, "Please Fill above field first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                progressDialog.setTitle("Updating Coupon");
                progressDialog.setMessage("Please wait while we updating coupon amount");
                progressDialog.show();

                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Coupons");
                HashMap hashMap = new HashMap();
                hashMap.put("coupon_number", model.getCoupon_number());
                hashMap.put("coupon_amount", String.valueOf(couponamountEdit.getText().toString()));
                hashMap.put("coupon_key", model.getCoupon_key());

                mDatabase.child(model.getCoupon_key()).updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        Toast.makeText(EditCoupon.this, "Coupon Updated", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(EditCoupon.this, AllCoupons.class));
                        finish();
                    }
                });


            }
        });




    }
}
