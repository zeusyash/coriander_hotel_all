package fujdevelopers.com.jaaflongtandooricms.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Activities.EditSubProduct;
import fujdevelopers.com.jaaflongtandooricms.Activities.SubActivity;
import fujdevelopers.com.jaaflongtandooricms.Model.ProductModel;
import fujdevelopers.com.jaaflongtandooricms.R;


public class SubProductAdapter extends RecyclerView.Adapter<SubProductAdapter.ViewHolder> {

    List<ProductModel> list;
    Context context;

    public SubProductAdapter(List<ProductModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.cat_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final ProductModel model = list.get(position);

        holder.productName.setText(model.getProductName());
        Glide.with(context).load(model.getProductImage()).into(holder.productImage);

        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SubActivity.cat_number == 1){
                    context.startActivity(new Intent(context, EditSubProduct.class).putExtra("Product", model));
                } else if (SubActivity.cat_number == 2){
                    context.startActivity(new Intent(context, EditSubProduct.class).putExtra("Product", model));
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView productName;
        ImageView productImage;

        CardView bgCard;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            productName = itemView.findViewById(R.id.cat_name_cat_card);
            productImage = itemView.findViewById(R.id.cat_image_cat_card);

            bgCard = itemView.findViewById(R.id.cat_bg_card);
        }
    }
}
