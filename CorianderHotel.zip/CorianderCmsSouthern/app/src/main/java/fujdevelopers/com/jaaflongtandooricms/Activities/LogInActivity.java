package fujdevelopers.com.jaaflongtandooricms.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.valdesekamdem.library.mdtoast.MDToast;

import fujdevelopers.com.jaaflongtandooricms.R;

public class LogInActivity extends AppCompatActivity {

    EditText emailEdit, passwordEdit;

    Button loginBtn;
    TextView forgetpass;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        mAuth = FirebaseAuth.getInstance();

        findViewById(R.id.forgetPass).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LogInActivity.this,ForgotPasswordActivity.class));
            }
        });

        progressDialog = new ProgressDialog(this);

        findViewById(R.id.register_btn_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LogInActivity.this, SignUpActivity.class));
            }
        });


        emailEdit = findViewById(R.id.email_edit_login);
        passwordEdit = findViewById(R.id.password_edit_login);

        loginBtn = findViewById(R.id.login_btn_login);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emailEdit.getText().toString().isEmpty() || passwordEdit.getText().toString().isEmpty()) {
                    MDToast.makeText(LogInActivity.this, "Please Fill above fields first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                progressDialog.setTitle("Logging in");
                progressDialog.setMessage("Please wait while we log you in.");
                progressDialog.show();

                mAuth.signInWithEmailAndPassword(emailEdit.getText().toString().trim(), passwordEdit.getText().toString())
                        .addOnCompleteListener(LogInActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("LOGGING", "signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    FirebaseMessaging.getInstance().subscribeToTopic("adminb");

                                    updateUI();
                                    //updateUI(user);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w("LOGGING", "signInWithEmail:failure", task.getException());
                                    Toast.makeText(LogInActivity.this, "Authentication failed : " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                    progressDialog.dismiss();
                                    //updateUI(null);
                                }

                                // ...
                            }
                        });

            }
        });

    }

//    S8IQ1naR68erwhev56uJ2EmuB923
    private void updateUI() {

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountType").child(mAuth.getCurrentUser().getUid());
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    progressDialog.dismiss();
                        startActivity(new Intent(LogInActivity.this, MainActivity.class));
                        finish();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

}
