package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.util.ArrayList;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.ProductModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class EditProduct extends AppCompatActivity {



    ProductModel productModel;

    DatabaseReference mDatabaseForProductUploading;

    String Selected_Category_ID;
    String Selected_Category_Name;
    String SUBSelected_Category_ID="";
    String SUBSelected_Category_Name="";


    private TextView Category_Name_View;
    private ArrayList<String> Catagories_Names = new ArrayList<>();
    private ArrayList<String> Catagories_ID = new ArrayList<>();

    private Dialog Category_Select_Dialog;
    EditText Category_Search_Box;
    ListView Category_List_View;
    private ArrayAdapter<String> Category_Item_Adapter;

    private TextView SUBCategory_Name_View;
    private ArrayList<String> SUBCatagories_Names = new ArrayList<>();
    private ArrayList<String> SUBCatagories_ID = new ArrayList<>();
    private Dialog SUBCategory_Select_Dialog;
    EditText SUBCategory_Search_Box;
    ListView SUBCategory_List_View;
    private ArrayAdapter<String> SUBCategory_Item_Adapter;


    EditText productName, productPrice, productDisc;
    CircleImageView productImage;
    Button addProduct, deleteFoodBtn;

    Uri resultUri;
    int picSelected = 0;
    String imageUrl;

    ProgressDialog progressDialog;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        productModel = (ProductModel) getIntent().getSerializableExtra("Product");
        Fetch_Categories();
        Category_Select();
        Category_Name_View = findViewById(R.id.Category_View_Id);

        SUBCategory_Name_View = findViewById(R.id.Sub_Category_View_Id);

        SUBCategory_Name_View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SUBCatagories_ID.clear();
                SUBCatagories_Names.clear();
                Fetch_SUBCategories();
                SUBCategory_Select();
                SUBCategory_Select_Dialog.show();
            }
        });


        Category_Name_View.setText(productModel.getCatName());
        Category_Name_View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Category_Select_Dialog.show();
            }
        });

        initViews();

    }


    private void initViews(){

        mDatabaseForProductUploading = FirebaseDatabase.getInstance().getReference().child("Categories").child(productModel.getCatId()).child("Products");


        Selected_Category_ID = productModel.getCatId();
        Selected_Category_Name = productModel.getCatName();

        progressDialog = new ProgressDialog(this);

        productName = findViewById(R.id.product_name_edit_add);
        productName.setText(productModel.getProductName());
        productPrice = findViewById(R.id.product_price_edit_add);
        productPrice.setText(productModel.getProductPrice());
        productDisc=  findViewById(R.id.product_disc_edit_add);
        productDisc.setText(productModel.getProductDiscription());
        productImage = findViewById(R.id.product_image_add);
        Glide.with(this).load(productModel.getProductImage()).into(productImage);
        productImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CropImage.activity()
                        .setAspectRatio(1, 1)
                        .start(EditProduct.this);
            }
        });
        addProduct = findViewById(R.id.add_product_btn);
        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (productName.getText().toString().isEmpty() || productDisc.getText().toString().isEmpty() || productPrice.getText().toString().isEmpty() || Selected_Category_ID.isEmpty()){
                    MDToast.makeText(EditProduct.this, "Please Fill All THe fields above FIrst.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

/*
                if (picSelected == 0){
                    uploadDataToDatabase();
                } else if (picSelected == 1){
                    uploadImageFirst();
                }
*/
                uploadDataToDatabase();

            }
        });

        deleteFoodBtn = findViewById(R.id.delete_food_btn);
        deleteFoodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(EditProduct.this);
                builder.setMessage("Do you really want to delete this food?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Categories").child(productModel.getCatId()).child("Products").child(productModel.getProductId());
                        mDatabase.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {

                                MDToast.makeText(EditProduct.this, "Food Removed Successfully.", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                                dialog.dismiss();
                                finish();
                            }
                        });
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();
            }
        });
    }


    private void uploadImageFirst(){

        progressDialog.setTitle("Uploading Image");
        progressDialog.setMessage("Please Wait while we Upload your Product");
        progressDialog.show();

        final StorageReference Submit_Datareference = FirebaseStorage.getInstance().getReference("ProductImages").child(productModel.getProductId());
        Submit_Datareference.putFile(resultUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Submit_Datareference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        //imagesUrl.add(uri.toString());

                        productModel.setProductImage(uri.toString());

                        uploadDataToDatabase();

                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                //Dialog.Set_Percetage((int) progress);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(EditProduct.this, "Error!", Toast.LENGTH_LONG).show();
                progressDialog.dismiss();
            }
        });

    }

    private void uploadDataToDatabase(){

        if(SUBSelected_Category_ID.equals("")){
            mDatabaseForProductUploading = FirebaseDatabase.getInstance().getReference().child("Categories").child(Selected_Category_ID).child("Products");
        }
        else{
            mDatabaseForProductUploading = FirebaseDatabase.getInstance().getReference().child("Categories").child(Selected_Category_ID).child("Subcat").child(SUBSelected_Category_ID).child("Products");
        }

        productModel.setProductImage("adfadlflb");

        HashMap Data = new HashMap();
        Data.put("productName", productName.getText().toString());
        Data.put("productDiscription", productDisc.getText().toString());
        Data.put("productImage", productModel.getProductImage());
        Data.put("catId", Selected_Category_ID);
        Data.put("catName", Selected_Category_Name);
        Data.put("productPrice", String.valueOf(productPrice.getText().toString()));
        Data.put("productId", productModel.getProductId());

        mDatabaseForProductUploading.child(productModel.getProductId()).updateChildren(Data).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                MDToast.makeText(EditProduct.this, "Food Edited", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                finish();
            }
        });
    }


    private void Category_Select() {
        Category_Select_Dialog = new Dialog(this);
        Category_Select_Dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        Category_Select_Dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Category_Select_Dialog.setContentView(R.layout.select_layout);
        Category_Select_Dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        Category_Select_Dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        Category_Select_Dialog.setCancelable(true);
        Category_Search_Box = Category_Select_Dialog.findViewById(R.id.Search_Data_Edit);
        Category_List_View = Category_Select_Dialog.findViewById(R.id.List_View_Id);
        String[] item = {"1"};
        Category_Item_Adapter = new ArrayAdapter<String>(EditProduct.this, R.layout.list_row, item);
        Category_List_View.setAdapter(Category_Item_Adapter);
        Category_List_View.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Category_Select_Dialog.dismiss();
                String selectedFromList = (Category_List_View.getItemAtPosition(i)).toString();
                Category_Name_View.setText(selectedFromList);
                Selected_Category_ID = Catagories_ID.get(i);
                Selected_Category_Name = selectedFromList;
            }
        });

        Category_Search_Box.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Call back the Adapter with current character to Filter
                Category_Item_Adapter.getFilter().filter(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void Fetch_Categories() {

        String[] item = {""};
    Category_Item_Adapter = new ArrayAdapter<String>(EditProduct.this, R.layout.list_row, item);
    DatabaseReference Reference = FirebaseDatabase.getInstance().getReference().child("Categories");
        Reference.addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            for (DataSnapshot Child : dataSnapshot.getChildren()) {
                Catagories_ID.add(Child.getKey());
                Catagories_Names.add(Child.child("catName").getValue().toString());
            }
            Category_Item_Adapter = new ArrayAdapter<String>(EditProduct.this, R.layout.list_row, Catagories_Names);
            Category_List_View.setAdapter(Category_Item_Adapter);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
        }
    });
}

    private void Fetch_SUBCategories() {
        String[] item = {""};
        SUBCategory_Item_Adapter = new ArrayAdapter<String>(EditProduct.this, R.layout.list_row, item);
        DatabaseReference Reference = FirebaseDatabase.getInstance().getReference().child("Categories").child(Selected_Category_ID).child("Subcat");
        Reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot Child : dataSnapshot.getChildren()) {
                    SUBCatagories_ID.add(Child.child("sid").getValue().toString());
                    SUBCatagories_Names.add(Child.child("catName").getValue().toString());
                }
                SUBCategory_Item_Adapter = new ArrayAdapter<String>(EditProduct.this, R.layout.list_row, SUBCatagories_Names);
                SUBCategory_List_View.setAdapter(SUBCategory_Item_Adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    private void SUBCategory_Select() {
        SUBCategory_Select_Dialog = new Dialog(this);
        SUBCategory_Select_Dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        SUBCategory_Select_Dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        SUBCategory_Select_Dialog.setContentView(R.layout.select_layout);
        SUBCategory_Select_Dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        SUBCategory_Select_Dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.FILL_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        SUBCategory_Select_Dialog.setCancelable(true);
        SUBCategory_Search_Box = SUBCategory_Select_Dialog.findViewById(R.id.Search_Data_Edit);
        SUBCategory_List_View = SUBCategory_Select_Dialog.findViewById(R.id.List_View_Id);
//        String[] item = {"1"};
//        Category_Item_Adapter = new ArrayAdapter<String>(AddProduct.this, R.layout.list_row, item);
        SUBCategory_List_View.setAdapter(SUBCategory_Item_Adapter);
        SUBCategory_List_View.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                SUBCategory_Select_Dialog.dismiss();
                String selectedFromList = (SUBCategory_List_View.getItemAtPosition(i)).toString();
                SUBCategory_Name_View.setText(selectedFromList);
                SUBSelected_Category_ID = SUBCatagories_ID.get(i);
                SUBSelected_Category_Name = selectedFromList;
            }
        });

        SUBCategory_Search_Box.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Call back the Adapter with current character to Filter
                SUBCategory_Item_Adapter.getFilter().filter(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                resultUri = result.getUri();

                picSelected = 1;

     Glide.with(EditProduct.this).load(resultUri).into(productImage);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();

                Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

}
