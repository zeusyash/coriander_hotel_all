package fujdevelopers.com.jaaflongtandooricms.Adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.RectangleReadOnly;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.valdesekamdem.library.mdtoast.MDToast;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.PendingOrderModel;
import fujdevelopers.com.jaaflongtandooricms.R;

import static com.itextpdf.text.PageSize.A4;


public class PendingOrderAdapter extends RecyclerView.Adapter<PendingOrderAdapter.ViewHolder> {

//    int selectedOrder = 0;

    List<PendingOrderModel> list;
    Context context;

//    //selecting workers
//    String Selected_Worker_ID;
//    String Selected_Worker_Name;
//
////    private Dialog Worker_Select_Dialog;
////    EditText Worker_Search_Box;
////    ListView Worker_List_View;
////    private ArrayAdapter<String> Worker_Item_Adapter;
////    private ArrayList<String> Workers_Names = new ArrayList<>();
////    private ArrayList<String> Workers_ID = new ArrayList<>();

    public PendingOrderAdapter(List<PendingOrderModel> list, Context context) {
        this.list = list;
        this.context = context;

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
//        Worker_Select();
//        Fetch_Workers();
    }

    @NonNull
    @Override
    public PendingOrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.pending_order_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PendingOrderAdapter.ViewHolder holder, final int position) {
        invoice_dialoge();
        final PendingOrderModel model = list.get(position);
        holder.bookerName.setText(model.getBookerName());
        holder.address.setText(model.getAddress());
        holder.totalPrice.setText(model.getTotalCost());
        holder.orderDetails.setText(model.getOrderDetails());
        holder.orderStatus.setText(model.getStatus());

        if(model.getAllergies().equals("") || model.getAllergies().equals(" ")){

        }
        else{
            holder.allergiesLay.setVisibility(View.VISIBLE);
            holder.allergiesTb.setText(model.getAllergies());
        }

        holder.type.setText(model.getType());

        if (model.getStatus().equals("New")) {
            holder.acceptorder.setVisibility(View.VISIBLE);
            holder.rejectorder.setVisibility(View.VISIBLE);
            holder.showUser.setVisibility(View.VISIBLE);
            holder.completeorder.setVisibility(View.GONE);
            holder.generate_invoice.setVisibility(View.GONE);
        } else if (model.getStatus().equals("Pending")) {

            holder.acceptorder.setVisibility(View.GONE);
            holder.rejectorder.setVisibility(View.GONE);
            holder.showUser.setVisibility(View.GONE);
            holder.completeorder.setVisibility(View.VISIBLE);
            holder.generate_invoice.setVisibility(View.VISIBLE);

        } else if (model.getStatus().equals("Rejected")) {

            holder.acceptorder.setVisibility(View.GONE);
            holder.rejectorder.setVisibility(View.GONE);
            holder.showUser.setVisibility(View.GONE);
            holder.completeorder.setVisibility(View.GONE);

        }
        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        holder.showUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!model.getBookerId().equals(""))
                showUserInfoDialog(model);
                else
                    Toast.makeText(context,"Guest User",Toast.LENGTH_SHORT).show();
            }
        });
        holder.rejectorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RejectOrder(model.getOrderId());
            }
        });
        holder.completeorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CompletOrders(model.getOrderId());
            }
        });
        holder.acceptorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AcceptOrder(model.getOrderId());
            }
        });
        holder.generate_invoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                getorderdetail(model.getOrderId());


                Log.d("Checking_Order_ID", "dasdasdasdas:=" + model.getOrderId());


            }
        });


    }

    private void CompletOrders(String orderId) {

        final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);

        HashMap hashMap = new HashMap();
        hashMap.put("Status", "Completed");
        mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                MDToast.makeText(context, "Order Accepted").show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                MDToast.makeText(context, "Error Accepting Order Try again Later").show();
            }
        });
    }

    private Dialog Order_Invoice_Dialoge;
    private TextView username,  ordebill, orderdetail, adresss, orderdate, show_date;
    private Button printInvoice;
    private void invoice_dialoge() {
        Order_Invoice_Dialoge = new Dialog(context);
        Order_Invoice_Dialoge.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        Order_Invoice_Dialoge.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Order_Invoice_Dialoge.setCancelable(true);


        Order_Invoice_Dialoge.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT
        );


        Order_Invoice_Dialoge.setContentView(R.layout.order_invoice_view);
        username = Order_Invoice_Dialoge.findViewById(R.id.booker_name);
        orderdetail = Order_Invoice_Dialoge.findViewById(R.id.order_details);
        orderdate = Order_Invoice_Dialoge.findViewById(R.id.order_date);
        ordebill = Order_Invoice_Dialoge.findViewById(R.id.total_price);
        show_date = Order_Invoice_Dialoge.findViewById(R.id.show_date);
        printInvoice = Order_Invoice_Dialoge.findViewById(R.id.print_order_invoice);
        adresss = Order_Invoice_Dialoge.findViewById(R.id.worker_name);


        printInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openpdff();
            }
        });



    }

    private String detail, name, address, numberOfFoods, date, totalCost, order_date, Order_Number;
    private String phno,type;
    private ArrayList<String> pquantity = new ArrayList<>();
    private ArrayList<String> pname = new ArrayList<>();
    private ArrayList<String> pprice = new ArrayList<>();
    private ArrayList<String> ptotal = new ArrayList<>();
    private ArrayList<String> sdescr = new ArrayList<>();

    private void getorderdetail(String orderId) {


        DatabaseReference OrderDataReference = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);
        OrderDataReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot != null) {
                    name = dataSnapshot.child("Name").getValue().toString();
                    address = dataSnapshot.child("Address").getValue().toString();
                    phno = dataSnapshot.child("phno").getValue().toString();
                    type = dataSnapshot.child("Type").getValue().toString();
                    Order_Number = dataSnapshot.child("OrderId").getValue().toString();
                    numberOfFoods = String.valueOf(dataSnapshot.child("NumberOfFoods").getValue(Integer.class));
                    try {
                        date = dataSnapshot.child("Order_Time").getValue().toString();
                        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(Long.parseLong(date));

                        order_date = formatter.format(calendar.getTime());

                    } catch (Exception e) {

                    }

                    totalCost = dataSnapshot.child("TotalCost").getValue().toString() ;
                    int number = Integer.parseInt(numberOfFoods);
                    detail = " ";
                    for (int i = 0; i < number; i++) {
                        int quantity = dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class);
                        pquantity.add(String.valueOf(quantity));
                        double price = Double.parseDouble(dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString());
                        pprice.add(String.valueOf(price));
                        String name_product = dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString();
                        pname.add(name_product);
                        double total = quantity * price;
                        String formattedValue = String.format("%.2f", total);

                        ptotal.add(formattedValue);

                        try{

                            if(!dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString().equals(" ")) {
                                detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\n( " + dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString() + " )\n   Price : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                String descr = dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString();
                                sdescr.add(descr);
                            }
                            else{
                                detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                sdescr.add("N/A");
                            }

                        }
                        catch (Exception e){
                            detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                            sdescr.add("N/A");
                        }                    }


                }


                username.setText(name);
                adresss.setText(address);
                orderdetail.setText(detail);
                ordebill.setText(totalCost);
                if (date != null) {
                    orderdate.setText(order_date);
                } else {
                    orderdate.setVisibility(View.GONE);
                    show_date.setVisibility(View.GONE);
                }

                createPDF();
                Order_Invoice_Dialoge.show();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


                private void AcceptOrder (String orderId){


                    final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);

                    HashMap hashMap = new HashMap();
                    hashMap.put("Status", "Pending");
                    mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            MDToast.makeText(context, "Order Accepted").show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            MDToast.makeText(context, "Error Accepting Order Try again Later").show();
                        }
                    });


                }

                private void RejectOrder (String orderId){


                    final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);

                    HashMap hashMap = new HashMap();
                    hashMap.put("Status", "Rejected");
                    mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            MDToast.makeText(context, "Order Rejected").show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            MDToast.makeText(context, "Error Rejecting Order Try again Later").show();
                        }
                    });


                }

                private void showUserInfoDialog (PendingOrderModel model){
                    //Means he has clicked on add Barber option
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                    //setting up the layout for alert dialog
                    View view1 = LayoutInflater.from(context).inflate(R.layout.show_user_dialog, null, false);

                    builder1.setView(view1);

                    final CircleImageView userImage = view1.findViewById(R.id.image_user_);
                    final TextView userName = view1.findViewById(R.id.name_user_);
                    TextView addressUser = view1.findViewById(R.id.address_user_);
                    addressUser.setText(model.getAddress());

                    Button dismissDialog = view1.findViewById(R.id.dismiss_btn);

                    DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(model.getBookerId());
                    mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String name = dataSnapshot.child("user_name").getValue().toString();
                            userName.setText(name);
                            String image = "";
                            if (dataSnapshot.hasChild("user_image")) {
                                image = dataSnapshot.child("user_image").getValue().toString();
                                try {
                                    Glide.with(context).load(image).into(userImage);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                    final AlertDialog dialogg = builder1.create();
                    dialogg.show();

                    dismissDialog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialogg.dismiss();
                        }
                    });
                }

                @Override
                public int getItemCount () {
                    return list.size();
                }

                public class ViewHolder extends RecyclerView.ViewHolder {

                    TextView bookerName,allergiesTb, totalPrice, address, orderDetails, orderStatus, type;
                    CardView bgCard;
                    LinearLayout allergiesLay;

                    Button showUser, rejectorder, acceptorder, completeorder, generate_invoice;

                    public ViewHolder(@NonNull View itemView) {
                        super(itemView);


                        type = itemView.findViewById(R.id.type);
                        allergiesLay = itemView.findViewById(R.id.allergieslay);
                        allergiesTb = itemView.findViewById(R.id.allergies);
                        bookerName = itemView.findViewById(R.id.booker_name_order_card);
                        totalPrice = itemView.findViewById(R.id.total_price_order_card);
                        address = itemView.findViewById(R.id.address_order_card);
                        orderDetails = itemView.findViewById(R.id.order_detail_order_card);
                        bgCard = itemView.findViewById(R.id.bg_card_pending_card);
                        orderStatus = itemView.findViewById(R.id.order_status_order_card);
                        showUser = itemView.findViewById(R.id.show_user_btn_pending_order_card);
                        rejectorder = itemView.findViewById(R.id.reject_order);
                        acceptorder = itemView.findViewById(R.id.accept_order);
                        completeorder = itemView.findViewById(R.id.complete_order);
                        generate_invoice = itemView.findViewById(R.id.generate_invoice);
                    }
                }

//    private void Worker_Select() {
//        Worker_Select_Dialog = new Dialog(context);
//        Worker_Select_Dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
//        Worker_Select_Dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//        Worker_Select_Dialog.setContentView(R.layout.select_layout);
//        Worker_Select_Dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
//        Worker_Select_Dialog.getWindow().setLayout(
//                ViewGroup.LayoutParams.FILL_PARENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT
//        );
//        Worker_Select_Dialog.setCancelable(true);
//        Worker_Search_Box = Worker_Select_Dialog.findViewById(R.id.Search_Data_Edit);
//        Worker_List_View = Worker_Select_Dialog.findViewById(R.id.List_View_Id);
//        String[] item = {"1"};
//        Worker_Item_Adapter = new ArrayAdapter<String>(context, R.layout.list_row, item);
//        Worker_List_View.setAdapter(Worker_Item_Adapter);
//        Worker_List_View.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                Worker_Select_Dialog.dismiss();
//                String selectedFromList = (Worker_List_View.getItemAtPosition(i)).toString();
//                Selected_Worker_ID = Workers_ID.get(i);
//                Selected_Worker_Name = selectedFromList;
//
//                assignThisWorker();
//            }
//        });
//
//        Worker_Search_Box.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                // Call back the Adapter with current character to Filter
//                Worker_Item_Adapter.getFilter().filter(s.toString());
//            }
//
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//            }
//        });
//    }

//    private void assignThisWorker(){
//
//        final PendingOrderModel model = list.get(selectedOrder);
//
//        final DatabaseReference mDatabaseForBooking = FirebaseDatabase.getInstance().getReference().child("Orders").child(model.getOrderId());
//
//        HashMap Data = new HashMap();
//        Data.put("AssignedWorkerId", Selected_Worker_ID);
//        Data.put("AssignedWorkerName", Selected_Worker_Name);
//
//        mDatabaseForBooking.updateChildren(Data).addOnSuccessListener(new OnSuccessListener() {
//            @Override
//            public void onSuccess(Object o) {
//                mDatabaseForBooking.child("Status").setValue("Accepted");
//                DatabaseReference Notification_Reference = FirebaseDatabase.getInstance().getReference("OrderAcceptanceNotification").child(model.getBookerId());
//                String Notif_Id = Notification_Reference.push().getKey();
//                HashMap Notif_map = new HashMap();
//                Notif_map.put("From", "Admin");
//                Notif_map.put("Type", "Message");
//                Notification_Reference.child(Notif_Id).updateChildren(Notif_map);
//
//            }
//        });
//    }

//    private void Fetch_Workers() {
//        String[] item = {""};
//        Worker_Item_Adapter = new ArrayAdapter<String>(context, R.layout.list_row, item);
//        DatabaseReference Reference = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Worker");
//        Reference.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                for (DataSnapshot Child : dataSnapshot.getChildren()) {
//
//                    if (Child.hasChild("isAvailable")){
//                        if (Child.child("isAvailable").getValue(Boolean.class)){
//                            Workers_ID.add(Child.getKey());
//                            Workers_Names.add(Child.child("Name").getValue().toString());
//                        }
//                    }
//                }
//                Worker_Item_Adapter = new ArrayAdapter<String>(context, R.layout.list_row, Workers_Names);
//                Worker_List_View.setAdapter(Worker_Item_Adapter);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//            }
//        });
//    }

                File dir;
                String loc;
                public void createPDF () {

                    /**
                     * Creating Document
                     */

                    Log.d("Checking_PDF_FILE", "sfasfasf");
                    Document document = new Document();


                    dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Food App" + Order_Number);
                    if (!dir.exists())
                        dir.mkdirs();
//
                    loc = "PlacemantTracking " + System.currentTimeMillis() + ".pdf";

                    File file = new File(dir, loc);
                    if (!file.exists())
                        file.delete();

// Location to save
                    try {
                        PdfWriter.getInstance(document, new FileOutputStream(file));

                        Font font = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
                        document.open();

                        // Document Settings
                        Rectangle customforJaflang = new RectangleReadOnly(80,279);

                        document.setPageSize(customforJaflang);
//                        document.setPageSize(A4);
                        document.addCreationDate();
//            Paragraph paragraph = new Paragraph();


//            PdfPTable table = new PdfPTable(2);

                        // Image From drawable to pdf File
                        Drawable d = context.getResources().getDrawable(R.drawable.clock_lo);
                        BitmapDrawable bitDw = ((BitmapDrawable) d);
                        Bitmap bmp = bitDw.getBitmap();
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        Image image = Image.getInstance(stream.toByteArray());
                        image.scalePercent(9); ///Image Size
                        image.setAbsolutePosition(250f, 735f); //Image Position


                        Log.d("Checking_PDF_FILE", "sfasfasf" + stream.toByteArray());


                        PdfPTable totaltable = new PdfPTable(2);
                        totaltable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);

                        totaltable.addCell("Order Number");
                        totaltable.addCell("Grand Total");
                        totaltable.setHeaderRows(1); //Setting First Row as header
                        PdfPCell[] ordercell = totaltable.getRow(0).getCells();
                        for (int j = 0; j < ordercell.length; j++) {
                            ordercell[j].setBackgroundColor(BaseColor.GRAY);

                        }// Assigning header row color grey
                        totaltable.addCell(String.valueOf(Order_Number));
                        totaltable.addCell(totalCost+"£");


                        PdfPTable table = new PdfPTable(6); //No of Columns in table
                        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
                        table.addCell("Sr #");
                        table.addCell("Product Name");
                        table.addCell("Request");
                        table.addCell("Quantity");
                        table.addCell("Product Price");
                        table.addCell("Total");
                        table.setHeaderRows(1); //Setting First Row as header

                        PdfPCell[] cells = table.getRow(0).getCells();
                        for (int j = 0; j < cells.length; j++) {
                            cells[j].setBackgroundColor(BaseColor.GRAY);
                        }// Assigning header row color grey
                        for (int i = 0; i < Integer.parseInt(numberOfFoods); i++) {
                            int sr = i + 1;
                            table.addCell(String.valueOf(sr));
                            table.addCell(pname.get(i));
                            table.addCell(sdescr.get(i));
                            table.addCell(pquantity.get(i));
                            table.addCell(pprice.get(i));
                            table.addCell(pquantity.get(i) + "*" + pprice.get(i) + "=" + ptotal.get(i));
                        }//Adding Values in rows

                        // Paragragh in PDF File
                        String bname = "\n\n\n\n\n" + "Customer Name" + "        :" + "     " + name;
                        String bdate = "Order Date" + "                 :" + "    " + order_date ;
                        String wname = "Address" + "                     :"+"     " + address;
                        String phnol = "Phone Number" + "          :"+"     " + phno;
                        String typel = "Type" + "                           :"+"     " + type+ "\n\n\n";
                        String line = "\n\n";
                        String lineNone = "";


                        Paragraph pname = new Paragraph(bname, font);
                        pname.setAlignment(Element.ALIGN_LEFT); //Align Centre Paragragh lines
                        document.add(pname);
                        Paragraph pdate = new Paragraph(bdate, font);
                        pdate.setAlignment(Element.ALIGN_LEFT);
                        document.add(pdate);
                        Paragraph pwname = new Paragraph(wname, font);
                        pwname.setAlignment(Element.ALIGN_LEFT);
                        document.add(pwname);
                        Paragraph phnoline = new Paragraph(phnol, font);
                        pwname.setAlignment(Element.ALIGN_LEFT);
                        document.add(phnoline);
                        Paragraph typeline = new Paragraph(typel, font);
                        typeline.setAlignment(Element.ALIGN_LEFT);
                        document.add(typeline);


                        String invoice_date = "";
                        try {
                            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy   hh:mm:ss");
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTimeInMillis(System.currentTimeMillis());
                            invoice_date = formatter.format(calendar.getTime());

                        } catch (Exception e) {

                        }


                        String invoice_print_time = "\n\n\n\n\nInvoice Print Date   " + "   " + invoice_date;
                        Paragraph invoice_time = new Paragraph(invoice_print_time, font);
                        invoice_time.setAlignment(Element.ALIGN_RIGHT);

                        Paragraph paragraph = new Paragraph(lineNone, font);

                        document.add(image);
                        document.add(table);
                        document.add(paragraph);
                        document.add(totaltable);
                        document.add(invoice_time);


                        printInvoice.setVisibility(View.VISIBLE);

                    } catch (DocumentException e) {
                        e.printStackTrace();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        document.close();
                    }


// Open to write

                }
                private void openpdff () {


                    Log.d("Checking_PDF_FILE", "PDF OPENING");


                    File pdfFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Food App" + Order_Number+ "/" + loc);
                    Uri path = Uri.fromFile(pdfFile);

                    // Setting the intent for pdf reader
                    Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
                    pdfIntent.setDataAndType(path, "application/pdf");
                    pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                    try {
                        context.startActivity(pdfIntent);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(context, "Can't read pdf file", Toast.LENGTH_SHORT).show();
                    }
                }
            }
