package fujdevelopers.com.jaaflongtandooricms.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Model.ReservationModel;
import fujdevelopers.com.jaaflongtandooricms.R;


public class ReservationAdapter extends RecyclerView.Adapter<ReservationAdapter.ViewHolder> {

//    int selectedOrder = 0;

    List<ReservationModel> list;
    Context context;

//    //selecting workers
//    String Selected_Worker_ID;
//    String Selected_Worker_Name;
//
////    private Dialog Worker_Select_Dialog;
////    EditText Worker_Search_Box;
////    ListView Worker_List_View;
////    private ArrayAdapter<String> Worker_Item_Adapter;
////    private ArrayList<String> Workers_Names = new ArrayList<>();
////    private ArrayList<String> Workers_ID = new ArrayList<>();

    public ReservationAdapter(List<ReservationModel> list, Context context) {
        this.list = list;
        this.context = context;

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
//        Worker_Select();
//        Fetch_Workers();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.reservation_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final ReservationModel model = list.get(position);

        holder.name.setText(model.getName());
        holder.email.setText(model.getEmail());
        holder.date.setText(model.getDate());
        holder.nop.setText(model.getNop());
        holder.note.setText(model.getNote());
        holder.phno.setText(model.getPhno());
        holder.type.setText(model.getType());
        holder.time_slot.setText(model.getTime_slot());
        holder.status.setText(model.getStatus());


        if (model.getStatus().equals("Pending")) {
            holder.acceptorder.setVisibility(View.VISIBLE);
            holder.rejectorder.setVisibility(View.VISIBLE);
            holder.showUser.setVisibility(View.GONE);
            holder.completeorder.setVisibility(View.GONE);
            holder.generate_invoice.setVisibility(View.GONE);
        }
        else {
            holder.mail_invoice.setVisibility(View.VISIBLE);
            holder.acceptorder.setVisibility(View.GONE);
            holder.rejectorder.setVisibility(View.GONE);
        }

        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        holder.rejectorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RejectOrder(model);
            }
        });
        holder.acceptorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AcceptOrder(model);
            }
        });
        holder.mail_invoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Mail_send(model);
            }
        });



    }

    private Dialog Order_Invoice_Dialoge;
    private TextView username,  ordebill, orderdetail, adresss, orderdate, show_date;
    private Button printInvoice;


    private String detail, name, address, numberOfFoods, date, totalCost, order_date, Order_Number;
    private String phno,type;
    private ArrayList<String> pquantity = new ArrayList<>();
    private ArrayList<String> pname = new ArrayList<>();
    private ArrayList<String> sdescr = new ArrayList<>();
    private ArrayList<String> pprice = new ArrayList<>();
    private ArrayList<String> ptotal = new ArrayList<>();



                private void AcceptOrder (ReservationModel model){


                    final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Reservation").child(model.getId());

                    HashMap hashMap = new HashMap();
                    hashMap.put("Status", "Accepted");
                    mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            MDToast.makeText(context, "Reservation Accepted, Configuring email").show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            MDToast.makeText(context, "Error Accepting Reservation Try again Later").show();
                        }
                    });

                    try
                    {
                        final Intent emailIntent = new Intent(Intent.ACTION_SEND);
                        emailIntent.setType("plain/text");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[] { model.getEmail() });
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Coriander");
                /*        if (URI != null) {
                            emailIntent.putExtra(Intent.EXTRA_STREAM, URI);
                        }*/
                        String body="Reservation is Accepted at Coriander Restaurant for the following: <br><br> Name: "+model.getName()+"<br>Email: "+model.getEmail()+"<br>Date: "+model.getDate()+"<br>Number of People: "+model.getNop()+"<br>Time Slot: "+model.getTime_slot()+"<br> Type: "+model.getType()+"<br>Phone Number: "+model.getPhno()+"<br>Note: "+model.getNote();
//                        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Reservation is Accepted at Coriander Restaurant for the following <br> Name: "+model.getName()+"\nEmail: "+model.getEmail()+"\nDate: "+model.getDate()+"\nNumber of People: "+model.getNop()+"\nTime Slot: "+model.getTime_slot()+"\n Type: "+model.getType()+"\nPhone Number: "+model.getPhno());
                        emailIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(body));
                        context.startActivity(Intent.createChooser(emailIntent,"Sending email..."));
                    }
                    catch (Throwable t)
                    {
                        Toast.makeText(context, "Request failed try again: " + t.toString(),Toast.LENGTH_LONG).show();
                    }


                }

                private void Mail_send (ReservationModel model){


                    try
                    {
                        final Intent emailIntent = new Intent(Intent.ACTION_SEND);
                        emailIntent.setType("plain/text");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[] { model.getEmail() });
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Coriander");
                /*        if (URI != null) {
                            emailIntent.putExtra(Intent.EXTRA_STREAM, URI);
                        }*/
                        String body=" ";
                        if(model.getStatus().equals("Accepted")){
                            body="Reservation is Accepted at Coriander Restaurant for the following: <br><br> Name: "+model.getName()+"<br>Email: "+model.getEmail()+"<br>Date: "+model.getDate()+"<br>Number of People: "+model.getNop()+"<br>Time Slot: "+model.getTime_slot()+"<br> Type: "+model.getType()+"<br>Phone Number: "+model.getPhno()+"<br>Note: "+model.getNote();
                        }
                        else{
                            body="Reservation is Rejected at Coriander Restaurant for the following: <br><br> Name: "+model.getName()+"<br>Email: "+model.getEmail()+"<br>Date: "+model.getDate()+"<br>Number of People: "+model.getNop()+"<br>Time Slot: "+model.getTime_slot()+"<br> Type: "+model.getType()+"<br>Phone Number: "+model.getPhno()+"<br>Note: "+model.getNote();
                        }
//                        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Reservation is Accepted at Coriander Restaurant for the following <br> Name: "+model.getName()+"\nEmail: "+model.getEmail()+"\nDate: "+model.getDate()+"\nNumber of People: "+model.getNop()+"\nTime Slot: "+model.getTime_slot()+"\n Type: "+model.getType()+"\nPhone Number: "+model.getPhno());
                        emailIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(body));

//                        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Your Reservation is "+ status +" at Coriander Restaurant");
                        context.startActivity(Intent.createChooser(emailIntent,"Sending email..."));
                    }
                    catch (Throwable t)
                    {
                        Toast.makeText(context, "Request failed try again: " + t.toString(),Toast.LENGTH_LONG).show();
                    }


                }

                private void RejectOrder (ReservationModel model){


                    final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Reservation").child(model.getId());

                    HashMap hashMap = new HashMap();
                    hashMap.put("Status", "Rejected");
                    mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            MDToast.makeText(context, "Reservation Rejected").show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            MDToast.makeText(context, "Error Rejecting Reservation Try again Later").show();
                        }
                    });

                    try
                    {
                        final Intent emailIntent = new Intent(Intent.ACTION_SEND);
                        emailIntent.setType("plain/text");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[] { model.getEmail() });
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Coriander");
                /*        if (URI != null) {
                            emailIntent.putExtra(Intent.EXTRA_STREAM, URI);
                        }*/
                        String body="Reservation is Rejected at Coriander Restaurant for the following: <br><br> Name: "+model.getName()+"<br>Email: "+model.getEmail()+"<br>Date: "+model.getDate()+"<br>Number of People: "+model.getNop()+"<br>Time Slot: "+model.getTime_slot()+"<br> Type: "+model.getType()+"<br>Phone Number: "+model.getPhno()+"<br>Note: "+model.getNote();
//                        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Reservation is Accepted at Coriander Restaurant for the following <br> Name: "+model.getName()+"\nEmail: "+model.getEmail()+"\nDate: "+model.getDate()+"\nNumber of People: "+model.getNop()+"\nTime Slot: "+model.getTime_slot()+"\n Type: "+model.getType()+"\nPhone Number: "+model.getPhno());
                        emailIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(body));
                        context.startActivity(Intent.createChooser(emailIntent,"Sending email..."));
                    }
                    catch (Throwable t)
                    {
                        Toast.makeText(context, "Request failed try again: " + t.toString(),Toast.LENGTH_LONG).show();
                    }


                }


                @Override
                public int getItemCount () {
                    return list.size();
                }

                public class ViewHolder extends RecyclerView.ViewHolder {

                    TextView name, email, date, nop, note, phno, time_slot, status, type;
                    CardView bgCard;

                    Button showUser, rejectorder, acceptorder, completeorder, generate_invoice,mail_invoice;

                    public ViewHolder(@NonNull View itemView) {
                        super(itemView);


//                        address = itemView.findViewById(R.id.address_order_card);
                        type = itemView.findViewById(R.id.typetxt);
                        name = itemView.findViewById(R.id.nametxt);
                        email = itemView.findViewById(R.id.emailtxt);
                        phno = itemView.findViewById(R.id.phnotxt);
                        nop = itemView.findViewById(R.id.peopletxt);
                        note = itemView.findViewById(R.id.notetxt);
                        date = itemView.findViewById(R.id.datetxt);
                        time_slot = itemView.findViewById(R.id.timeslot);
                        status = itemView.findViewById(R.id.statustxt);

                        bgCard = itemView.findViewById(R.id.bg_card_pending_card);
                        showUser = itemView.findViewById(R.id.show_user_btn_pending_order_card);
                        rejectorder = itemView.findViewById(R.id.reject_order);
                        acceptorder = itemView.findViewById(R.id.accept_order);
                        completeorder = itemView.findViewById(R.id.complete_order);
                        generate_invoice = itemView.findViewById(R.id.generate_invoice);
                        mail_invoice = itemView.findViewById(R.id.send_invoice);
                    }
                }


                File dir;
                String loc;
            }
