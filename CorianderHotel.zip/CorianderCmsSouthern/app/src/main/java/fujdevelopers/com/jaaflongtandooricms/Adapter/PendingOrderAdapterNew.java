package fujdevelopers.com.jaaflongtandooricms.Adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.os.StrictMode;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.RectangleReadOnly;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandooricms.Model.PendingOrderModelNew;
import fujdevelopers.com.jaaflongtandooricms.R;


public class PendingOrderAdapterNew extends RecyclerView.Adapter<PendingOrderAdapterNew.ViewHolder> {

//    int selectedOrder = 0;
    String m_Text="";
    List<PendingOrderModelNew> list;
    Context context;

//    //selecting workers
//    String Selected_Worker_ID;
//    String Selected_Worker_Name;
//
////    private Dialog Worker_Select_Dialog;
////    EditText Worker_Search_Box;
////    ListView Worker_List_View;
////    private ArrayAdapter<String> Worker_Item_Adapter;
////    private ArrayList<String> Workers_Names = new ArrayList<>();
////    private ArrayList<String> Workers_ID = new ArrayList<>();

    public PendingOrderAdapterNew(List<PendingOrderModelNew> list, Context context) {
        this.list = list;
        this.context = context;

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
//        Worker_Select();
//        Fetch_Workers();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.pending_order_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        invoice_dialoge();
        final PendingOrderModelNew model = list.get(position);
        holder.bookerName.setText(model.getBookerName());
        holder.address.setText(model.getAddress());
        holder.totalPrice.setText(model.getTotalCost());
        holder.orderDetails.setText(model.getOrderDetails());
        holder.orderStatus.setText(model.getStatus());

        if(model.getAllergies().equals("") || model.getAllergies().equals(" ")){

        }
        else{
            holder.allergiesLay.setVisibility(View.VISIBLE);
            holder.allergiesTb.setText(model.getAllergies());
        }

        holder.type.setText(model.getType());

        if (model.getStatus().equals("New")) {
            holder.acceptorder.setVisibility(View.VISIBLE);
            holder.rejectorder.setVisibility(View.VISIBLE);
            holder.showUser.setVisibility(View.VISIBLE);
            holder.completeorder.setVisibility(View.GONE);
            holder.generate_invoice.setVisibility(View.GONE);
        } else if (model.getStatus().equals("Pending")) {

            holder.acceptorder.setVisibility(View.GONE);
            holder.rejectorder.setVisibility(View.GONE);
            holder.showUser.setVisibility(View.GONE);
            holder.completeorder.setVisibility(View.VISIBLE);
            holder.generate_invoice.setVisibility(View.VISIBLE);

        } else if (model.getStatus().equals("Rejected")) {

            holder.acceptorder.setVisibility(View.GONE);
            holder.rejectorder.setVisibility(View.GONE);
            holder.showUser.setVisibility(View.GONE);
            holder.completeorder.setVisibility(View.GONE);

        } else if (model.getStatus().equals("Completed")) {

        holder.generate_invoice.setVisibility(View.VISIBLE);
        holder.acceptorder.setVisibility(View.GONE);
        holder.rejectorder.setVisibility(View.GONE);
        holder.showUser.setVisibility(View.GONE);
        holder.completeorder.setVisibility(View.GONE);
        holder.send_mail.setVisibility(View.VISIBLE);


    }

        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        holder.showUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!model.getBookerId().equals(""))
                showUserInfoDialog(model);
                else
                    Toast.makeText(context,"Guest User",Toast.LENGTH_SHORT).show();
            }
        });
        holder.rejectorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RejectOrder(model.getOrderId());
            }
        });
        holder.completeorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(model.getType().toString().equalsIgnoreCase("Delivery") || model.getType().toString().equalsIgnoreCase("Takeaway")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Enter Time Required");

// Set up the input
                    final EditText input = new EditText(context);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
                    input.setInputType(InputType.TYPE_CLASS_NUMBER);
                    builder.setView(input);

// Set up the buttons
                    builder.setPositiveButton("Proceed", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            m_Text = input.getText().toString();
                            getorderdetailComplete(model);

                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    builder.show();

                }
                else{
                    getorderdetailComplete(model);
                }

            }
        });
        holder.acceptorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AcceptOrder(model.getOrderId());
            }
        });
        holder.generate_invoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                getorderdetail(model.getOrderId());


                Log.d("Checking_Order_ID", "dasdasdasdas:=" + model.getOrderId());


            }
        });

        holder.send_mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getorderdetailComplete(model);

            }
        });


    }

    private void CompletOrders(String orderId, final String email, final Uri uri) {

        final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);

        HashMap hashMap = new HashMap();
        hashMap.put("Status", "Completed");
        mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                MDToast.makeText(context, "Order Accepted").show();

                if(email.equals(" ")) {
                    Toast.makeText(context, "Email not found of user!", Toast.LENGTH_LONG).show();
                }
                else{
                    try {
                        final Intent emailIntent = new Intent(Intent.ACTION_SEND);
                        emailIntent.setType("plain/text");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Coriander");
                        if (uri != null) {
                            emailIntent.putExtra(Intent.EXTRA_STREAM, uri);
                        }
                        if(m_Text.equals("")){
                            emailIntent.putExtra(Intent.EXTRA_TEXT, "Your Order is Completed at Coriander Restaurant");
                        }
                        else{
                            emailIntent.putExtra(Intent.EXTRA_TEXT, "Your Order is Completed at Coriander Restaurant and will be ready in "+m_Text+" minutes.");
                        }
                        context.startActivity(Intent.createChooser(emailIntent, "Sending email..."));
                        Toast.makeText(context, "Send Email to Customer", Toast.LENGTH_LONG).show();
                        m_Text="";

                    } catch (Throwable t) {
                        m_Text="";
                        Toast.makeText(context, "Request failed try again: " + t.toString(), Toast.LENGTH_LONG).show();
                    }
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                MDToast.makeText(context, "Error Accepting Order Try again Later").show();
            }
        });
    }

    private Dialog Order_Invoice_Dialoge;
    private TextView username,  ordebill, orderdetail, adresss, orderdate, show_date;
    private Button printInvoice;
    private void invoice_dialoge() {
        Order_Invoice_Dialoge = new Dialog(context);
        Order_Invoice_Dialoge.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        Order_Invoice_Dialoge.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Order_Invoice_Dialoge.setCancelable(true);


        Order_Invoice_Dialoge.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT
        );


        Order_Invoice_Dialoge.setContentView(R.layout.order_invoice_view);
        username = Order_Invoice_Dialoge.findViewById(R.id.booker_name);
        orderdetail = Order_Invoice_Dialoge.findViewById(R.id.order_details);
        orderdate = Order_Invoice_Dialoge.findViewById(R.id.order_date);
        ordebill = Order_Invoice_Dialoge.findViewById(R.id.total_price);
        show_date = Order_Invoice_Dialoge.findViewById(R.id.show_date);
        printInvoice = Order_Invoice_Dialoge.findViewById(R.id.print_order_invoice);
        adresss = Order_Invoice_Dialoge.findViewById(R.id.worker_name);


        printInvoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openpdff();
            }
        });



    }

    private String detail, name, address, numberOfFoods, date, totalCost, order_date, Order_Number;
    private String phno,type,special_note;
    private ArrayList<String> pquantity = new ArrayList<>();
    private ArrayList<String> pname = new ArrayList<>();
    private ArrayList<String> sdescr = new ArrayList<>();
    private ArrayList<String> pprice = new ArrayList<>();
    private ArrayList<String> ptotal = new ArrayList<>();

    private void getorderdetail(String orderId) {


        DatabaseReference OrderDataReference = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);
        OrderDataReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot != null) {
                    name = dataSnapshot.child("Name").getValue().toString();
                    address = dataSnapshot.child("Address").getValue().toString();
                    phno = dataSnapshot.child("phno").getValue().toString();
                    special_note = dataSnapshot.child("Allergies").getValue().toString();
                    type = dataSnapshot.child("Type").getValue().toString();
                    Order_Number = dataSnapshot.child("OrderId").getValue().toString();
                    numberOfFoods = String.valueOf(dataSnapshot.child("NumberOfFoods").getValue(Integer.class));
                    try {
                        date = dataSnapshot.child("Order_Time").getValue().toString();
                        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(Long.parseLong(date));

                        order_date = formatter.format(calendar.getTime());

                    } catch (Exception e) {

                    }

                    totalCost = dataSnapshot.child("TotalCost").getValue().toString() ;
                    int number = Integer.parseInt(numberOfFoods);
                    detail = " ";
                    for (int i = 0; i < number; i++) {
                        int quantity = dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class);
                        pquantity.add(String.valueOf(quantity));
                        double price = Double.parseDouble(dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString());
                        pprice.add(String.valueOf(price));
                        String name_product = dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString();
                        pname.add(name_product);
                        double total = quantity * price;
                        String formattedValue = String.format("%.2f", total);

                        ptotal.add(formattedValue);

                        try{

                            if(!dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString().equals(" ")) {
                                detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\n( " + dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString() + " )\n   Price : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                String descr = dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString();
                                sdescr.add(descr);
                            }
                            else{
                                detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                sdescr.add("N/A");
                            }

                        }
                        catch (Exception e){
                            detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                            sdescr.add("N/A");
                        }
                    }


                }


                username.setText(name);
                adresss.setText(address);
                orderdetail.setText(detail);
                ordebill.setText(totalCost);
                if (date != null) {
                    orderdate.setText(order_date);
                } else {
                    orderdate.setVisibility(View.GONE);
                    show_date.setVisibility(View.GONE);
                }

                createPDF();
                Order_Invoice_Dialoge.show();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void getorderdetailComplete(final PendingOrderModelNew model) {


        DatabaseReference OrderDataReference = FirebaseDatabase.getInstance().getReference().child("Orders").child(model.getOrderId());
        OrderDataReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot != null) {
                    name = dataSnapshot.child("Name").getValue().toString();
                    address = dataSnapshot.child("Address").getValue().toString();
                    phno = dataSnapshot.child("phno").getValue().toString();
                    type = dataSnapshot.child("Type").getValue().toString();
                    special_note = dataSnapshot.child("Allergies").getValue().toString();
                    Order_Number = dataSnapshot.child("OrderId").getValue().toString();
                    numberOfFoods = String.valueOf(dataSnapshot.child("NumberOfFoods").getValue(Integer.class));
                    try {
                        date = dataSnapshot.child("Order_Time").getValue().toString();
                        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTimeInMillis(Long.parseLong(date));

                        order_date = formatter.format(calendar.getTime());

                    } catch (Exception e) {

                    }

                    totalCost = dataSnapshot.child("TotalCost").getValue().toString() ;
                    int number = Integer.parseInt(numberOfFoods);
                    detail = " ";
                    for (int i = 0; i < number; i++) {
                        int quantity = dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class);
                        pquantity.add(String.valueOf(quantity));
                        double price = Double.parseDouble(dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString());
                        pprice.add(String.valueOf(price));
                        String name_product = dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString();
                        pname.add(name_product);
                        double total = quantity * price;
                        String formattedValue = String.format("%.2f", total);

                        ptotal.add(formattedValue);

                        try{

                            if(!dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString().equals(" ")) {
                                detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\n( " + dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString() + " )\n   Price : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                String descr = dataSnapshot.child(String.valueOf(i)).child("shortdescr").getValue().toString();
                                sdescr.add(descr);
                            }
                            else{
                                detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                                sdescr.add("N/A");
                            }

                        }
                        catch (Exception e){
                            detail = detail + dataSnapshot.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + dataSnapshot.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + dataSnapshot.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue + "\n\n";
                            sdescr.add("N/A");
                        }
                    }


                }


                username.setText(name);
                adresss.setText(address);
                orderdetail.setText(detail);
                ordebill.setText(totalCost);
                if (date != null) {
                    orderdate.setText(order_date);
                } else {
                    orderdate.setVisibility(View.GONE);
                    show_date.setVisibility(View.GONE);
                }
                createPDF_Complete(model.getOrderId(),model.getEmail());
                //Order_Invoice_Dialoge.show();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


                private void AcceptOrder (String orderId){


                    final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);

                    HashMap hashMap = new HashMap();
                    hashMap.put("Status", "Pending");
                    mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            MDToast.makeText(context, "Order Accepted").show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            MDToast.makeText(context, "Error Accepting Order Try again Later").show();
                        }
                    });


                }

                private void RejectOrder (String orderId){


                    final DatabaseReference mDatabaseForDeleteOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child(orderId);

                    HashMap hashMap = new HashMap();
                    hashMap.put("Status", "Rejected");
                    mDatabaseForDeleteOrder.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            MDToast.makeText(context, "Order Rejected").show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            MDToast.makeText(context, "Error Rejecting Order Try again Later").show();
                        }
                    });


                }

                private void showUserInfoDialog (PendingOrderModelNew model){
                    //Means he has clicked on add Barber option
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                    //setting up the layout for alert dialog
                    View view1 = LayoutInflater.from(context).inflate(R.layout.show_user_dialog, null, false);

                    builder1.setView(view1);

                    final CircleImageView userImage = view1.findViewById(R.id.image_user_);
                    final TextView userName = view1.findViewById(R.id.name_user_);
                    TextView addressUser = view1.findViewById(R.id.address_user_);
                    addressUser.setText(model.getAddress());

                    Button dismissDialog = view1.findViewById(R.id.dismiss_btn);

                    DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(model.getBookerId());
                    mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String name = dataSnapshot.child("user_name").getValue().toString();
                            userName.setText(name);
                            String image = "";
                            if (dataSnapshot.hasChild("user_image")) {
                                image = dataSnapshot.child("user_image").getValue().toString();
                                try {
                                    Glide.with(context).load(image).into(userImage);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                    final AlertDialog dialogg = builder1.create();
                    dialogg.show();

                    dismissDialog.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialogg.dismiss();
                        }
                    });
                }

                @Override
                public int getItemCount () {
                    return list.size();
                }

                public class ViewHolder extends RecyclerView.ViewHolder {

                    TextView bookerName,allergiesTb, totalPrice, address, orderDetails, orderStatus, type;
                    CardView bgCard;
                    LinearLayout allergiesLay;

                    Button showUser, rejectorder, acceptorder, completeorder, generate_invoice, send_mail;

                    public ViewHolder(@NonNull View itemView) {
                        super(itemView);


                        type = itemView.findViewById(R.id.type);
                        allergiesLay = itemView.findViewById(R.id.allergieslay);
                        allergiesTb = itemView.findViewById(R.id.allergies);
                        bookerName = itemView.findViewById(R.id.booker_name_order_card);
                        totalPrice = itemView.findViewById(R.id.total_price_order_card);
                        address = itemView.findViewById(R.id.address_order_card);
                        orderDetails = itemView.findViewById(R.id.order_detail_order_card);
                        bgCard = itemView.findViewById(R.id.bg_card_pending_card);
                        orderStatus = itemView.findViewById(R.id.order_status_order_card);
                        showUser = itemView.findViewById(R.id.show_user_btn_pending_order_card);
                        rejectorder = itemView.findViewById(R.id.reject_order);
                        acceptorder = itemView.findViewById(R.id.accept_order);
                        completeorder = itemView.findViewById(R.id.complete_order);
                        generate_invoice = itemView.findViewById(R.id.generate_invoice);
                        send_mail = itemView.findViewById(R.id.send_mail);
                    }
                }

                File dir;
                String loc;
                public void createPDF () {

                    /**
                     * Creating Document
                     */

                    Log.d("Checking_PDF_FILE", "sfasfasf");
                    Document document = new Document();


                    dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Food App" + Order_Number);
                    if (!dir.exists())
                        dir.mkdirs();
//
                    loc = "CorianderOrder " + System.currentTimeMillis() + ".pdf";

                    File file = new File(dir, loc);
                    if (!file.exists())
                        file.delete();

// Location to save
                    try {
                        PdfWriter.getInstance(document, new FileOutputStream(file));

                        Font font = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
                        document.open();

                        // Document Settings
                        Rectangle customforJaflang = new RectangleReadOnly(226,881);

                        document.setPageSize(customforJaflang);
                        document.setMargins(0f,0f,0f,0f);
//                        document.setPageSize(A4);
                        document.addCreationDate();
//            Paragraph paragraph = new Paragraph();


//            PdfPTable table = new PdfPTable(2);

                        // Image From drawable to pdf File
                        Drawable d = context.getResources().getDrawable(R.drawable.clock_lo);
                        BitmapDrawable bitDw = ((BitmapDrawable) d);
                        Bitmap bmp = bitDw.getBitmap();
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        Image image = Image.getInstance(stream.toByteArray());
                        image.scalePercent(9); ///Image Size
                        image.setAbsolutePosition(250f, 735f); //Image Position


                        Log.d("Checking_PDF_FILE", "sfasfasf" + stream.toByteArray());


                        PdfPTable totaltable = new PdfPTable(1);
                        totaltable.setWidthPercentage(100);


                        totaltable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);

/* -----------NEWWWWWW
                        PdfPCell onum=new PdfPCell(new Phrase("Order Number",font));
                        onum.setVerticalAlignment(Element.ALIGN_CENTER);
                        onum.setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.addCell(onum);
*/
                        totaltable.addCell(new PdfPCell(new Phrase("Grand Total",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.setHeaderRows(1); //Setting First Row as header
    //                        PdfPCell[] ordercell = totaltable.getRow(0).getCells();
      //                  for (int j = 0; j < ordercell.length; j++) {
//                            ordercell[j].setBackgroundColor(BaseColor.GRAY);

        //                }// Assigning header row color grey
// -------------NEWWW
//                      totaltable.addCell(new PdfPCell(new Phrase(String.valueOf(Order_Number),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.addCell(new PdfPCell(new Phrase(totalCost+"£",font))).setHorizontalAlignment(Element.ALIGN_CENTER);


                        PdfPTable table = new PdfPTable(5); //No of Columns in table
                        table.setWidths(new float[] { 1, 4, 3, 2, 4 });
                        table.setWidthPercentage(100);
                        //table.setWidthPercentage(100);
                        table.addCell(new PdfPCell(new Phrase("Sr",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(new PdfPCell(new Phrase("Product",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(new PdfPCell(new Phrase("Request",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(new PdfPCell(new Phrase("Qty",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
//                        table.addCell(new PdfPCell(new Phrase("Price",font)));
                        table.addCell(new PdfPCell(new Phrase("Total",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);

                        table.setHeaderRows(1); //Setting First Row as header

                        PdfPCell[] cells = table.getRow(0).getCells();
                        for (int j = 0; j < cells.length; j++) {
                 //           cells[j].setBackgroundColor(BaseColor.GRAY);
                        }// Assigning header row color grey
                        for (int i = 0; i < Integer.parseInt(numberOfFoods); i++) {
                            int sr = i + 1;
                            table.addCell(new PdfPCell(new Phrase(String.valueOf(sr),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                            table.addCell(new PdfPCell(new Phrase(pname.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                            table.addCell(new PdfPCell(new Phrase(sdescr.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                            table.addCell(new PdfPCell(new Phrase(pquantity.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
//                            table.addCell(new PdfPCell(new Phrase(pprice.get(i),font)));
                            table.addCell(new PdfPCell(new Phrase(pquantity.get(i) + "*" + pprice.get(i) + "=" + ptotal.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        }//Adding Values in rows

                        // Paragragh in PDF File
                        String bname = "Customer Name" + "        :" + "     " + name;
                        String bdate = "Order Date" + "                 :" + "    " + order_date ;
                        String wname = "Address" + "                     :"+"     " + address;
                        String phnol = "Phone Number" + "          :"+"     " + phno;
                        String typel = "Type" + "                           :"+"     " + type;
                        String special_note_t = "Special Note" + "              :"+"     " + special_note+ "\n\n";
                        String orderid = "Order Number" + "           :"+"     " + Order_Number;
                        String totall = "Total" + "                           :"+"     " + totalCost+"£";
                        String line = "\n\n";
                        String lineNone = "";


                        Paragraph oid = new Paragraph(orderid, font);
                        oid.setAlignment(Element.ALIGN_LEFT); //Align Centre Paragragh lines
                        document.add(oid);
                        Paragraph pname = new Paragraph(bname, font);
                        pname.setAlignment(Element.ALIGN_LEFT); //Align Centre Paragragh lines
                        document.add(pname);
                        Paragraph pdate = new Paragraph(bdate, font);
                        pdate.setAlignment(Element.ALIGN_LEFT);
                        document.add(pdate);
                        Paragraph pwname = new Paragraph(wname, font);
                        pwname.setAlignment(Element.ALIGN_LEFT);
                        document.add(pwname);
                        Paragraph phnoline = new Paragraph(phnol, font);
                        pwname.setAlignment(Element.ALIGN_LEFT);
                        document.add(phnoline);
                        Paragraph typeline = new Paragraph(typel, font);
                        typeline.setAlignment(Element.ALIGN_LEFT);
                        document.add(typeline);
                        Paragraph spnote = new Paragraph(special_note_t, font);
                        spnote.setAlignment(Element.ALIGN_LEFT);
                        document.add(spnote);
/* -------------NEWWWWWWWWWWW
                        Paragraph oid = new Paragraph(orderid, font);
                        oid.setAlignment(Element.ALIGN_LEFT);
                        document.add(oid);
*/
                        Paragraph total = new Paragraph(totall, font);
                        total.setAlignment(Element.ALIGN_LEFT);
                      //  document.add(total);

                        String invoice_date = "";
                        try {
                            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy   hh:mm:ss");
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTimeInMillis(System.currentTimeMillis());
                            invoice_date = formatter.format(calendar.getTime());

                        } catch (Exception e) {

                        }


                        String invoice_print_time = "\nInvoice Print Date   " + "   " + invoice_date;
                        Paragraph invoice_time = new Paragraph(invoice_print_time, font);
                        invoice_time.setAlignment(Element.ALIGN_LEFT);

                        Paragraph paragraph = new Paragraph(lineNone, font);

                        //document.add(image);
                        document.add(table);
                        document.add(paragraph);
                        document.add(totaltable);
                        document.add(invoice_time);


                        printInvoice.setVisibility(View.VISIBLE);

                    } catch (DocumentException e) {
                        e.printStackTrace();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        document.close();
                    }


// Open to write

                }

                public void createPDF_Complete (String model_orderid, String email) {

                    /**
                     * Creating Document
                     */

                    Log.d("Checking_PDF_FILE", "sfasfasf");
                    Document document = new Document();


                    dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Food App" + Order_Number);
                    if (!dir.exists())
                        dir.mkdirs();
//
                    loc = "PlacemantTracking " + System.currentTimeMillis() + ".pdf";

                    File file = new File(dir, loc);
                    if (!file.exists())
                        file.delete();

// Location to save
                    try {
                        PdfWriter.getInstance(document, new FileOutputStream(file));

                        Font font = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
                        document.open();

                        // Document Settings
                        Rectangle customforJaflang = new RectangleReadOnly(226,881);

                        document.setPageSize(customforJaflang);
                        document.setMargins(0f,0f,0f,0f);
//                        document.setPageSize(A4);
                        document.addCreationDate();
//            Paragraph paragraph = new Paragraph();


//            PdfPTable table = new PdfPTable(2);

                        // Image From drawable to pdf File
                        Drawable d = context.getResources().getDrawable(R.drawable.clock_lo);
                        BitmapDrawable bitDw = ((BitmapDrawable) d);
                        Bitmap bmp = bitDw.getBitmap();
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        Image image = Image.getInstance(stream.toByteArray());
                        image.scalePercent(9); ///Image Size
                        image.setAbsolutePosition(250f, 735f); //Image Position


                        Log.d("Checking_PDF_FILE", "sfasfasf" + stream.toByteArray());


                        PdfPTable totaltable = new PdfPTable(1);
                        totaltable.setWidthPercentage(100);


                        totaltable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);

/* -----------NEWWWWWW
                        PdfPCell onum=new PdfPCell(new Phrase("Order Number",font));
                        onum.setVerticalAlignment(Element.ALIGN_CENTER);
                        onum.setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.addCell(onum);
*/
                        totaltable.addCell(new PdfPCell(new Phrase("Grand Total",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.setHeaderRows(1); //Setting First Row as header
    //                        PdfPCell[] ordercell = totaltable.getRow(0).getCells();
      //                  for (int j = 0; j < ordercell.length; j++) {
//                            ordercell[j].setBackgroundColor(BaseColor.GRAY);

        //                }// Assigning header row color grey
// -------------NEWWW
//                      totaltable.addCell(new PdfPCell(new Phrase(String.valueOf(Order_Number),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        totaltable.addCell(new PdfPCell(new Phrase(totalCost+"£",font))).setHorizontalAlignment(Element.ALIGN_CENTER);


                        PdfPTable table = new PdfPTable(5); //No of Columns in table
                        table.setWidths(new float[] { 1, 4, 3, 2, 4 });
                        table.setWidthPercentage(100);
                        //table.setWidthPercentage(100);
                        table.addCell(new PdfPCell(new Phrase("Sr",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(new PdfPCell(new Phrase("Product",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(new PdfPCell(new Phrase("Request",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(new PdfPCell(new Phrase("Qty",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
//                        table.addCell(new PdfPCell(new Phrase("Price",font)));
                        table.addCell(new PdfPCell(new Phrase("Total",font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);

                        table.setHeaderRows(1); //Setting First Row as header

                        PdfPCell[] cells = table.getRow(0).getCells();
                        for (int j = 0; j < cells.length; j++) {
                 //           cells[j].setBackgroundColor(BaseColor.GRAY);
                        }// Assigning header row color grey
                        for (int i = 0; i < Integer.parseInt(numberOfFoods); i++) {
                            int sr = i + 1;
                            table.addCell(new PdfPCell(new Phrase(String.valueOf(sr),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                            table.addCell(new PdfPCell(new Phrase(pname.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                            table.addCell(new PdfPCell(new Phrase(sdescr.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                            table.addCell(new PdfPCell(new Phrase(pquantity.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
//                            table.addCell(new PdfPCell(new Phrase(pprice.get(i),font)));
                            table.addCell(new PdfPCell(new Phrase(pquantity.get(i) + "*" + pprice.get(i) + "=" + ptotal.get(i),font))).setHorizontalAlignment(Element.ALIGN_CENTER);
                        }//Adding Values in rows

                        // Paragragh in PDF File
                        String bname = "Customer Name" + "        :" + "     " + name;
                        String bdate = "Order Date" + "                 :" + "    " + order_date ;
                        String wname = "Address" + "                     :"+"     " + address;
                        String phnol = "Phone Number" + "          :"+"     " + phno;
                        String typel = "Type" + "                           :"+"     " + type+ "\n\n";
                        String special_note_t = "Special Note" + "           :"+"     " + special_note+ "\n\n";
                        String orderid = "Order Number" + "           :"+"     " + Order_Number;
                        String totall = "Total" + "                           :"+"     " + totalCost+"£";
                        String line = "\n\n";
                        String lineNone = "";


                        Paragraph oid = new Paragraph(orderid, font);
                        oid.setAlignment(Element.ALIGN_LEFT); //Align Centre Paragragh lines
                        document.add(oid);
                        Paragraph pname = new Paragraph(bname, font);
                        pname.setAlignment(Element.ALIGN_LEFT); //Align Centre Paragragh lines
                        document.add(pname);
                        Paragraph pdate = new Paragraph(bdate, font);
                        pdate.setAlignment(Element.ALIGN_LEFT);
                        document.add(pdate);
                        Paragraph pwname = new Paragraph(wname, font);
                        pwname.setAlignment(Element.ALIGN_LEFT);
                        document.add(pwname);
                        Paragraph phnoline = new Paragraph(phnol, font);
                        pwname.setAlignment(Element.ALIGN_LEFT);
                        document.add(phnoline);
                        Paragraph typeline = new Paragraph(typel, font);
                        typeline.setAlignment(Element.ALIGN_LEFT);
                        document.add(typeline);
                        Paragraph spnote = new Paragraph(special_note_t, font);
                        spnote.setAlignment(Element.ALIGN_LEFT);
                        document.add(spnote);
/* -------------NEWWWWWWWWWWW
                        Paragraph oid = new Paragraph(orderid, font);
                        oid.setAlignment(Element.ALIGN_LEFT);
                        document.add(oid);
*/
                        Paragraph total = new Paragraph(totall, font);
                        total.setAlignment(Element.ALIGN_LEFT);
                      //  document.add(total);

                        String invoice_date = "";
                        try {
                            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy   hh:mm:ss");
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTimeInMillis(System.currentTimeMillis());
                            invoice_date = formatter.format(calendar.getTime());

                        } catch (Exception e) {

                        }


                        String invoice_print_time = "\nInvoice Print Date   " + "   " + invoice_date;
                        Paragraph invoice_time = new Paragraph(invoice_print_time, font);
                        invoice_time.setAlignment(Element.ALIGN_LEFT);

                        Paragraph paragraph = new Paragraph(lineNone, font);

                        //document.add(image);
                        document.add(table);
                        document.add(paragraph);
                        document.add(totaltable);
                        document.add(invoice_time);


                        printInvoice.setVisibility(View.VISIBLE);

                    } catch (DocumentException e) {
                        e.printStackTrace();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        document.close();
                    }



                    File pdfFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Food App" + Order_Number+ "/" + loc);
                    Uri path = Uri.fromFile(pdfFile);

                    CompletOrders(model_orderid,email,path);

// Open to write

                }
                private void openpdff () {


                    Log.d("Checking_PDF_FILE", "PDF OPENING");


                    File pdfFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Food App" + Order_Number+ "/" + loc);
                    Uri path = Uri.fromFile(pdfFile);

                    // Setting the intent for pdf reader
                    Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
                    pdfIntent.setDataAndType(path, "application/pdf");
                    pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                    try {
                        context.startActivity(pdfIntent);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(context, "Can't read pdf file", Toast.LENGTH_SHORT).show();
                    }
                }
            }
