package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wang.avi.AVLoadingIndicatorView;

import java.util.ArrayList;
import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Adapter.SubCatAdapterInner;
import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.R;

public class AllSubCategoriesInner extends AppCompatActivity {


    RecyclerView categoriesRecycler;
    SubCatAdapterInner adapter;

    List<CatModel> list = new ArrayList<>();

    AVLoadingIndicatorView avi;
    CatModel catModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_categories);

        avi = findViewById(R.id.avi_all_cat);
        catModel = (CatModel) getIntent().getSerializableExtra("Category");



        categoriesRecycler = findViewById(R.id.categories_recyclers);
        adapter = new SubCatAdapterInner(list, this);
        categoriesRecycler.setAdapter(adapter);
        categoriesRecycler.setLayoutManager(new LinearLayoutManager(this));

        getData();
    }


    private void getData(){
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Categories").child(catModel.getCatId()).child("Subcat");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();

                for (DataSnapshot d: dataSnapshot.getChildren()){
                   CatModel catModel = d.getValue(CatModel.class);

                    Log.d("Checking___","Cat_Image " + catModel.getCatImage());
                    list.add(catModel);
                }
                Log.d("Checking___","List_Size " + list.size());


                avi.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
