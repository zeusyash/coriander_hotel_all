package fujdevelopers.com.jaaflongtandooricms.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import fujdevelopers.com.jaaflongtandooricms.Activities.AllSubProducts;
import fujdevelopers.com.jaaflongtandooricms.Activities.EditSubCategory;
import fujdevelopers.com.jaaflongtandooricms.Activities.SubActivity;
import fujdevelopers.com.jaaflongtandooricms.Model.CatModel;
import fujdevelopers.com.jaaflongtandooricms.R;


public class SubCatAdapterInner extends RecyclerView.Adapter<SubCatAdapterInner.ViewHolder> {

    List<CatModel> list;
    Context context;

    public SubCatAdapterInner(List<CatModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.cat_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {

        final CatModel model = list.get(position);

        holder.catName.setText(model.getCatName());

        Glide.with(context).load(model.getCatImage()).into(holder.catImage);

        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SubActivity.cat_number == 1){
                    context.startActivity(new Intent(context, EditSubCategory.class).putExtra("Category", model));
                } else if (SubActivity.cat_number == 2){
                    context.startActivity(new Intent(context, AllSubProducts.class).putExtra("Category", model));
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView catName;
        ImageView catImage;

        CardView bgCard;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            catName = itemView.findViewById(R.id.cat_name_cat_card);
            catImage = itemView.findViewById(R.id.cat_image_cat_card);

            bgCard = itemView.findViewById(R.id.cat_bg_card);
        }
    }
}
