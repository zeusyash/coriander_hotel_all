package fujdevelopers.com.jaaflongtandooricms.Activities;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import fujdevelopers.com.jaaflongtandooricms.R;

public class Notification extends AppCompatActivity {

    EditText text;
    Button change;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);



        progressDialog = new ProgressDialog(this);

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("message");

        text = findViewById(R.id.text);
        change = findViewById(R.id.change);

        FirebaseDatabase.getInstance().getReference().child("message").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Log.d("DSP",dataSnapshot.toString());
                text.setText(dataSnapshot.getValue().toString());

/*
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    text.setText(ds.getValue().toString());
                }
*/

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    //    text.setText(mDatabase.toString());

        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (change.getText().toString().isEmpty()) {

                }

                progressDialog.setTitle("Updating");
                progressDialog.setMessage("Please wait while we updating");
                progressDialog.show();

                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("message");
                mDatabase.setValue(text.getText().toString()).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(Notification.this, "Updated", Toast.LENGTH_SHORT).show();
                        onBackPressed();
                    }
                });



            }
        });

    }


}
