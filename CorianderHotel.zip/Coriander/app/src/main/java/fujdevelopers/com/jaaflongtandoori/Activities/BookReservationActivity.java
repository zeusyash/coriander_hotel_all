package fujdevelopers.com.jaaflongtandoori.Activities;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class BookReservationActivity extends AppCompatActivity {

    EditText emailet,noteet, nameet, phoneEdit;
    Button submitBtn;

    int typeselected=0;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;
        private CircleImageView Register_image;
    private Uri Image_uri;
    private String imgUrl;
    TextView datetxt;
    Spinner time_slot_spinner, nop_spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_reservation);

        getReservationNumber();

        datetxt=findViewById(R.id.datetxt);
        final Calendar myCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String myFormat = "dd/MM/yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                datetxt.setText(sdf.format(myCalendar.getTime()));
            }

        };

        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        datetxt.setText(sdf.format(myCalendar.getTime()));


        datetxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               DatePickerDialog dig= new DatePickerDialog(BookReservationActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
               dig.getDatePicker().setMinDate(System.currentTimeMillis() -1000);
               dig.show();
            }
        });



        time_slot_spinner = (Spinner) findViewById(R.id.time_slot_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item,getResources().getStringArray(R.array.time_slot));
        time_slot_spinner.setAdapter(adapter);

        nop_spinner = (Spinner) findViewById(R.id.nop_spinner);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, R.layout.spinner_item,getResources().getStringArray(R.array.nop));
        nop_spinner.setAdapter(adapter1);

        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);

        findViewById(R.id.smoking).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.nonsmoking).setBackgroundResource(0);
                findViewById(R.id.smoking).setBackgroundResource(R.drawable.btn_bg);
                typeselected=1;
            }
        });

        findViewById(R.id.nonsmoking).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.smoking).setBackgroundResource(0);
                findViewById(R.id.nonsmoking).setBackgroundResource(R.drawable.btn_bg);
                typeselected=0;
            }
        });

        findViewById(R.id.resetbtm).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emailet.setText("");
                phoneEdit.setText("");
                noteet.setText("");
                nameet.setText("");
            }
        });


        phoneEdit = findViewById(R.id.phnoet);
        emailet = findViewById(R.id.emailet);
        noteet = findViewById(R.id.noteatext);
        nameet = findViewById(R.id.nameet);


        submitBtn = findViewById(R.id.submit_btn);


        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (phoneEdit.getText().toString().isEmpty() ){
                    MDToast.makeText(BookReservationActivity.this, "Please fill all the fields above first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (emailet.getText().toString().isEmpty() || noteet.getText().toString().isEmpty() || nameet.getText().toString().isEmpty() || emailet.getText().toString().isEmpty() || phoneEdit.getText().toString().isEmpty() ){
                    MDToast.makeText(BookReservationActivity.this, "Please fill all the fields above first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (!isEmailvalid(emailet.getText().toString())) {
                    MDToast.makeText(BookReservationActivity.this, "Email is not valid", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }


                progressDialog.setTitle("Requesting..");
                progressDialog.setMessage("wait till we sent a request");
                progressDialog.show();


                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Reservation").child(String.valueOf(resno));

                HashMap Data = new HashMap();

                // String from=getIntent().getStringExtra("from");

                    Data.put("Id", resno);
                    Data.put("Name", nameet.getText().toString());
                    Data.put("Email",emailet.getText().toString());
                    Data.put("Phone",phoneEdit.getText().toString());
                    Data.put("Note",noteet.getText().toString());
                    Data.put("Date", datetxt.getText().toString());
                    Data.put("Time_Slot", time_slot_spinner.getSelectedItem().toString());
                    Data.put("NOP", nop_spinner.getSelectedItem().toString());
                    if(typeselected==1)
                        Data.put("Type","Smoking");
                    if(typeselected==0)
                        Data.put("Type","Non-Smoking");
                    Data.put("Status", "Pending");
                    Data.put("Restaurant", SelectionActivity.restaurant);

                mDatabase.updateChildren(Data).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {

                        if(SelectionInnerActivity.restaurant.equals("Coriander Southern Cemetery"))
                            Send_Notification("adminb");
                        else
                            Send_Notification("admina");


//                Send_Notification("admin");
//                Send_Notification("fujdevelopers.com.jaaflongtandooricms");
                        MDToast.makeText(BookReservationActivity.this, "Reservation requested").show();


                    }
                }).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        resno++;
                        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Reservation").child("ReservationNumber");
                        mDatabase.setValue(resno);
                        progressDialog.dismiss();
                        finish();
                    }
                });




            }
        });



    }



    int resno=1;
    private void getReservationNumber() {
        DatabaseReference mDatbase = FirebaseDatabase.getInstance().getReference().child("Reservation");
        mDatbase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("ReservationNumber")) {
                    resno = dataSnapshot.child("ReservationNumber").getValue(Integer.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void Send_Notification(final String topic)
    {
        RequestQueue mRequestQue = Volley.newRequestQueue(this);

        JSONObject json = new JSONObject();
        try {
            json.put("to", "/topics/" + topic);
            JSONObject notificationObj = new JSONObject();
            notificationObj.put("title", "Order");
            notificationObj.put("body", "You have a new Reservation !!");

            JSONObject data = new JSONObject();
            data.put("order", "new order");

            json.put("notification", notificationObj);
            json.put("data", data);

            String URL = "https://fcm.googleapis.com/fcm/send";
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL,
                    json,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.d("MUR", "onResponse: ");
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("MUR", "onError: " + error.networkResponse);
                        }
                    }
            ) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> header = new HashMap<>();
                    header.put("content-type", "application/json");
                    header.put("authorization", "key=AAAA92X2bvg:APA91bFB02SU280LBhSG0ZQlO4EkzpaJWrXeRSorcSP5CcRvbtn_6tG94PqaRXW1hwMyF5wM8uK8Yn6eRXcrHMhPxLPrDETB54vFhWsIvhqYg3czZ0qgw5jHXCNGnchmCKVvkPqJhMWf");
                    return header;
                }
            };


            mRequestQue.add(request);
        } catch (JSONException e) {
            e.printStackTrace();
        }    }





    private boolean isEmailvalid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        final CropImage.ActivityResult result = CropImage.getActivityResult(data);
        if (resultCode == RESULT_OK) {
            Image_uri = result.getUri();

            Glide.with(BookReservationActivity.this).load(Image_uri).into(Register_image);
        }

    }


}
