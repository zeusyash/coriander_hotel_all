package fujdevelopers.com.jaaflongtandoori.Activities;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.valdesekamdem.library.mdtoast.MDToast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Adapter.CartAdapter;
import fujdevelopers.com.jaaflongtandoori.Database.CartContract;
import fujdevelopers.com.jaaflongtandoori.Database.CartDbHelper;
import fujdevelopers.com.jaaflongtandoori.Model.CartProductModel;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class PaymentMethodActivity extends AppCompatActivity {


    //Drawer
    private DrawerLayout drawerLayout;
    private ImageView imageView;
    private NavigationView navigationView;
    TextView header_name,allergiesText;
    CircleImageView header_image;

    TextView coupon_applied;
    LinearLayout coupon_layout;


    List<CartProductModel> list = new ArrayList<>();
    FirebaseAuth mAuth;


    public static String selectedMethod;

    Button orderSummaryBtn, continueBtn, ApplyCoupon;
    private String couponNum, totalPriceText, Total_price;

    RadioGroup paymentMethod;

    RelativeLayout orderCompleteLayout;
    TextView orderNumberText, CouponText;
    private LinearLayout Coupon_Layout;
    Button backToHomeBtn;
    TextView totalPrice;

    double Total;
    SharedPreferences pref;
    SharedPreferences.Editor editor;

    int orderNumber = 1;

    private String Coupon_amount = "0";
    Boolean Check_Coupon = false;
    private EditText CouponNumber;

    ImageView cartImage;

    Boolean checkcoupon = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_method);

        mAuth = FirebaseAuth.getInstance();



            if(GuestDetailsStatic.Gname.equals(""))
                Navigation_Drawer();

        list = (List<CartProductModel>) getIntent().getSerializableExtra("Orders");

        pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();
        orderCompleteLayout = findViewById(R.id.complete_order_layout);
        orderCompleteLayout.setVisibility(View.GONE);
        orderNumberText = findViewById(R.id.order_number_order_complete);
        backToHomeBtn = findViewById(R.id.backtohome);
        orderSummaryBtn = findViewById(R.id.order_summary_btn_payment);
        continueBtn = findViewById(R.id.continueBtn_payment);

        paymentMethod = findViewById(R.id.payment_method);

        totalPrice = findViewById(R.id.total_price_text_payment);

        CouponNumber = findViewById(R.id.CoupNum);
        CouponText = findViewById(R.id.radioCoupon);
        Coupon_Layout = findViewById(R.id.coupon_num_lay);
        ApplyCoupon = findViewById(R.id.applycoupon);
        coupon_applied = findViewById(R.id.coupon_applied);
        allergiesText = findViewById(R.id.allergiesText);
        coupon_layout = findViewById(R.id.coupon_layout);

        checkcoupon = pref.getBoolean("key_name", false); // getting boolean

        if (checkcoupon) {
            coupon_layout.setVisibility(View.GONE);
            coupon_applied.setVisibility(View.VISIBLE);
        }


        Coupon_Layout.setVisibility(View.GONE);


        CouponText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Coupon_Layout.setVisibility(View.VISIBLE);
            }
        });
        ApplyCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                couponNum = CouponNumber.getText().toString();
                if (TextUtils.isEmpty(CouponNumber.getText().toString())) {
                    CouponNumber.setError("Enter a Coupon Name");
                    return;
                } else {
//                    Coupon_Layout.setVisibility(View.GONE);
//                    MDToast.makeText(PaymentMethodActivity.this, "Coupon isnot applicable at the moment!"+couponNum, MDToast.LENGTH_LONG).show();
                    Coupon_data();
                }

            }
        });

        cartImage = findViewById(R.id.cart_btn_main);

        cartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!GuestDetailsStatic.Gname.equals("")){
                    if (mAuth.getCurrentUser() != null) {
                        startActivity(new Intent(getApplicationContext(), CartActivity.class));

                    } else {
                        Log.d("GUESTCART","Login from 1");

                        startActivity(new Intent(getApplicationContext(), LogInActivity.class));
                        finish();
                        Toast.makeText(getApplicationContext(), "To Place Order LogIn First", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


        String totalPriceText = CartActivity.totalPriceTextCar;
        totalPrice.setText(totalPriceText);


        orderSummaryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                summary_dialoge();
                Order_Sumary_Dialoge.show();
            }
        });

        getOrderNumber();


        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                 //   String from = getIntent().getStringExtra("from");
                    if (!GuestDetailsStatic.Gname.equals("")) {
                        switch (paymentMethod.getCheckedRadioButtonId()) {
                            case R.id.radioCash:
                                selectedMethod = "CashOnDelivery";
                                placeOrder();
                                break;
                            case R.id.paypal:
//                            selectedMethod = "PayPal";
                                Toast.makeText(PaymentMethodActivity.this, "Coming Soon!", Toast.LENGTH_SHORT).show();
                                break;

                            default:
                        }

                    }
                    else {

                        if (mAuth.getCurrentUser() != null) {
                            continueBtn.setEnabled(false);

                            switch (paymentMethod.getCheckedRadioButtonId()) {
                                case R.id.radioCash:
                                    selectedMethod = "CashOnDelivery";
                                    placeOrder();
                                    break;
                                case R.id.paypal:
//                            selectedMethod = "PayPal";
                                    Toast.makeText(PaymentMethodActivity.this, "Coming Soon!", Toast.LENGTH_SHORT).show();
                                    break;

                                default:
                            }

                        }
                     else {
                            Log.d("GUESTCART","Login from 3");

                            startActivity(new Intent(PaymentMethodActivity.this, LogInActivity.class));
                        finish();
                     }

                    }

            }
        });


    }

    Double CouponAmount, NewPrice;

    private void Coupon_data() {

        Total = Double.valueOf(totalPrice.getText().toString());
        DatabaseReference CoupenRef = FirebaseDatabase.getInstance().getReference().child("Coupons");
        CoupenRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot Data : dataSnapshot.getChildren()) {


                    String coupon_number = Data.child("coupon_number").getValue().toString();


                    if (coupon_number.equals(couponNum)) {
                        Check_Coupon = true;
                        Coupon_amount = Data.child("coupon_amount").getValue().toString();

                    }
                }

                if (Check_Coupon) {

                    editor.putBoolean("coupon", true);
                    editor.commit();
                    editor.apply();
                    coupon_applied.setVisibility(View.VISIBLE);
                    coupon_layout.setVisibility(View.GONE);

                    CouponAmount = Double.parseDouble(Coupon_amount);
                    if (CouponAmount >= Total) {
//                        NewPrice = CouponAmount - Total;
//                        totalPrice.setText(String.valueOf(NewPrice));
//                        Total_price = totalPrice.getText().toString();
                        totalPrice.setText(String.valueOf(0));
                        Total_price = totalPrice.getText().toString();


                    } else if (Total > CouponAmount) {
                        NewPrice = Total - CouponAmount;
                        String formattedValue = String.format("%.2f", NewPrice);

                        totalPrice.setText(formattedValue);
                        Total_price = totalPrice.getText().toString();
                    }


                } else {
                    CouponNumber.setError("invalid coupon number");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    private void placeOrder() {

        int count = 1;

        CartDbHelper dbHelper = new CartDbHelper(this);

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int i = db.delete(CartContract.CARTTABLE, "1", null);
        //Toast.makeText(this, "Cart Cleared :" + i, Toast.LENGTH_SHORT).show();

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Orders").child(String.valueOf(orderNumber));
        for (int ii = 0; ii < list.size(); ii++) {
            CartProductModel model = list.get(ii);
            model.setId(count);
            count++;
            mDatabase.child(String.valueOf(ii)).setValue(model);
        }
        double ordertime = System.currentTimeMillis();


        HashMap Data = new HashMap();

       // String from=getIntent().getStringExtra("from");

        if(!GuestDetailsStatic.Gname.equals("")){
            Data.put("Name", GuestDetailsStatic.Gname);
            Data.put("Address",GuestDetailsStatic.Gaddr);
            Data.put("phno",GuestDetailsStatic.Gphno);
            Data.put("email",GuestDetailsStatic.Gmail);
            Data.put("UserId","");
            Data.put("NumberOfFoods", list.size());
            Data.put("OrderId", orderNumber);
            Data.put("TotalCost", totalPrice.getText().toString());
            Data.put("Status", "New");
            Data.put("Order_Time", ordertime);
            Data.put("Restaurant", SelectionInnerActivity.restaurant);
            Data.put("Type", SelectionInnerActivity.type);

            Data.put("Payment_Method", selectedMethod);
            Data.put("Allergies", allergiesText.getText().toString());
        }
        else{
            Data.put("Name", CartActivity.editname.toString());
            Data.put("Address", CartActivity.editaddress.toString());
            Data.put("phno", CartActivity.phno.toString());
            Data.put("email", CartActivity.email.toString());
            Data.put("UserId", mAuth.getCurrentUser().getUid());
            Data.put("NumberOfFoods", list.size());
            Data.put("OrderId", orderNumber);
            Data.put("TotalCost", totalPrice.getText().toString());
            Data.put("Status", "New");
            Data.put("Order_Time", ordertime);

            Data.put("Restaurant", SelectionInnerActivity.restaurant);
            Data.put("Type", SelectionInnerActivity.type);

            Data.put("Payment_Method", selectedMethod);
            Data.put("Allergies", allergiesText.getText().toString());
        }

        mDatabase.updateChildren(Data).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {

                editor.putBoolean("coupon", false);
                editor.commit();
                editor.apply();
                if(SelectionInnerActivity.restaurant.equals("Coriander Southern Cemetery"))
                    Send_Notification("adminb");
                else
                    Send_Notification("admina");


//                Send_Notification("admin");
//                Send_Notification("fujdevelopers.com.jaaflongtandooricms");
                MDToast.makeText(PaymentMethodActivity.this, "Order Placed").show();


            }
        }).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                orderNumber++;
                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Orders").child("OrdersNumber");
                mDatabase.setValue(orderNumber);

                orderCompleteLayout.setVisibility(View.VISIBLE);
                int order_no = orderNumber - 1;
                orderNumberText.setText(String.valueOf(order_no));

                backToHomeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(PaymentMethodActivity.this, MainActivity.class));
                        finish();
                    }
                });

                //here presenting order complete layout


            }
        });


    }

    private void Send_Notification(final String topic)
    {
        RequestQueue mRequestQue = Volley.newRequestQueue(this);

        JSONObject json = new JSONObject();
        try {
            json.put("to", "/topics/" + topic);
            JSONObject notificationObj = new JSONObject();
            notificationObj.put("title", "Order");
            notificationObj.put("body", "You have a new order !!");

            JSONObject data = new JSONObject();
            data.put("order", "new order");

            json.put("notification", notificationObj);
            json.put("data", data);

            String URL = "https://fcm.googleapis.com/fcm/send";
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL,
                    json,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.d("MUR", "onResponse: ");
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d("MUR", "onError: " + error.networkResponse);
                        }
                    }
            ) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> header = new HashMap<>();
                    header.put("content-type", "application/json");
                    header.put("authorization", "key=AAAA92X2bvg:APA91bFB02SU280LBhSG0ZQlO4EkzpaJWrXeRSorcSP5CcRvbtn_6tG94PqaRXW1hwMyF5wM8uK8Yn6eRXcrHMhPxLPrDETB54vFhWsIvhqYg3czZ0qgw5jHXCNGnchmCKVvkPqJhMWf");
                    return header;
                }
            };


            mRequestQue.add(request);
        } catch (JSONException e) {
            e.printStackTrace();
        }    }

    private void getOrderNumber() {
        DatabaseReference mDatbase = FirebaseDatabase.getInstance().getReference().child("Orders");
        mDatbase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("OrdersNumber")) {
                    orderNumber = dataSnapshot.child("OrdersNumber").getValue(Integer.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    Dialog Order_Sumary_Dialoge;
    TextView username, address, ordebill, detail_order;
    private CartAdapter adapter;

    public void summary_dialoge() {


        Order_Sumary_Dialoge = new Dialog(PaymentMethodActivity.this);
        Order_Sumary_Dialoge.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        Order_Sumary_Dialoge.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Order_Sumary_Dialoge.setCancelable(true);
        Order_Sumary_Dialoge.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.FILL_PARENT
        );
        Order_Sumary_Dialoge.setContentView(R.layout.order_summary_view);
        username = Order_Sumary_Dialoge.findViewById(R.id.booker_name);
        detail_order = Order_Sumary_Dialoge.findViewById(R.id.order_detail);
        address = Order_Sumary_Dialoge.findViewById(R.id.order_address);
        ordebill = Order_Sumary_Dialoge.findViewById(R.id.total_price);

        String detail = "";
        for (int i = 0; i < list.size(); i++) {
            int quantity = list.get(i).getQuantity();
            double price = Double.parseDouble(list.get(i).getProductPrice());
            double total = quantity * price;

            String formattedValue = String.format("%.2f", total);


            detail = detail + list.get(i).getProductName() + "\nPrice : " + list.get(i).getQuantity() + " x " + list.get(i).getProductPrice() + " = " + formattedValue + "£" + "\n\n";
        }

        username.setText(CartActivity.editname.toString());
        address.setText(CartActivity.editaddress.toString());
        ordebill.setText("£ " + totalPrice.getText().toString());
        detail_order.setText(detail);


    }


    private void Navigation_Drawer() {

        imageView = findViewById(R.id.menu_icon);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        View header = navigationView.getHeaderView(0);

        header_name = header.findViewById(R.id.name_header);
        header_image = header.findViewById(R.id.imageView_header);


        DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(mAuth.getCurrentUser().getUid());
        mDatabaseForManagement.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                header_name.setText(userModel.getUser_name());
                Picasso.get()
                        .load(userModel.getUser_image())
                        .into(header_image);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        ImageListener();
        NavigationListener();
    }

    private void ImageListener() {
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    private void NavigationListener() {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                int itemId = menuItem.getItemId();
                drawerLayout.closeDrawer(GravityCompat.START);

                switch (itemId) {

                    case R.id.home:
                        try {
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                        } catch (Exception e) {
                        }
                        break;

                    case R.id.order_history:
                        startActivity(new Intent(getApplicationContext(), OrderHistory.class));

                        break;


                    case R.id.share:
                        try {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("text/plain");
                            i.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                            final String appPackageName = getPackageName();
                            String Company_Data = "Try This Jaaflong Tandori App At \n" + "https://play.google.com/store/apps/details?id=" + appPackageName;
                            i.putExtra(Intent.EXTRA_TEXT, Company_Data);
                            startActivity(Intent.createChooser(i, "choose one"));
                        } catch (Exception e) {
                        }
                        break;
                    case R.id.nav_Rate:
                        Uri uri = Uri.parse("market://details?id=" + getApplicationContext().getPackageName());
                        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                        try {
                            startActivity(goToMarket);
                        } catch (ActivityNotFoundException e) {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        }
                        break;

                    case R.id.nav_signout:
                        mAuth.signOut();
                        Log.d("GUESTCART","Login from 5");

                        Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                        break;

                }


                return false;
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        CartDbHelper dbHelper = new CartDbHelper(this);

        String item_np = String.valueOf(dbHelper.getAllItems().size());

        TextView cart_item_no = findViewById(R.id.cart_items_number);
        if (dbHelper.getAllItems().size() > 0) {

            cart_item_no.setVisibility(View.VISIBLE);
            cart_item_no.setText(item_np);
        } else {
            cart_item_no.setVisibility(View.GONE);
        }


    }


}
