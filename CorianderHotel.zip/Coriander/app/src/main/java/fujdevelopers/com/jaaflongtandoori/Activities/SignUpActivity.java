package fujdevelopers.com.jaaflongtandoori.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;


import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class SignUpActivity extends AppCompatActivity {

    EditText emailEdit, paswordEdit, nameEdit , addressEdit, phoneEdit;
    Button registerBtn;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;
        private CircleImageView Register_image;
    private Uri Image_uri;
    private String imgUrl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);



        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);



        phoneEdit = findViewById(R.id.phone_edit_register);
        emailEdit = findViewById(R.id.email_edit_register);
        paswordEdit = findViewById(R.id.password_edit_register);
        nameEdit = findViewById(R.id.name_edit_register);
        addressEdit = findViewById(R.id.address_edit_register);
        Register_image = findViewById(R.id.user_image);
        getting_userImage();


        registerBtn = findViewById(R.id.register_btn_register);


        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri uri = Uri.parse("android.resource://yashwantgehlot.com.coriander/drawable/cooking");
                Image_uri=uri;


                if (phoneEdit.getText().toString().isEmpty() ){
                    MDToast.makeText(SignUpActivity.this, "Please fill all the fields above first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (emailEdit.getText().toString().isEmpty() || paswordEdit.getText().toString().isEmpty() || nameEdit.getText().toString().isEmpty() || addressEdit.getText().toString().isEmpty() || phoneEdit.getText().toString().isEmpty() ){
                    MDToast.makeText(SignUpActivity.this, "Please fill all the fields above first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (!isEmailvalid(emailEdit.getText().toString())) {
                    MDToast.makeText(SignUpActivity.this, "Email is not valid", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }


                progressDialog.setTitle("Registering your account");
                progressDialog.setMessage("Please while we register your account");
                progressDialog.show();

                mAuth.createUserWithEmailAndPassword(emailEdit.getText().toString().trim(), paswordEdit.getText().toString())
                        .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    FirebaseUser user = mAuth.getCurrentUser();
                                    uploadImageFirst();
                                } else {

                                    Toast.makeText(SignUpActivity.this, "Authentication failed : " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }

                                // ...
                            }

                        });
            }
        });



    }

    private void uploadImageFirst(){
        progressDialog.dismiss();
        progressDialog.setTitle("Uploading Data");
        progressDialog.setMessage("Please Wait while we upload data.");
        progressDialog.show();

        Uri uri = Uri.parse("android.resource://yashwantgehlot.com.coriander/drawable/cooking");
        Image_uri=uri;
        final StorageReference Submit_Datareference = FirebaseStorage.getInstance().getReference("UserImage").child(mAuth.getCurrentUser().getUid());
        Submit_Datareference.putFile(Image_uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Submit_Datareference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {

                        imgUrl = uri.toString();

                        updateUI();

                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                //Dialog.Set_Percetage((int) progress);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SignUpActivity.this, "Error: "+e.toString(), Toast.LENGTH_LONG).show();
                Log.d("EEER", "Error: "+e.toString());
                progressDialog.dismiss();
            }
        });

    }
//      APR, MAY < JUNE< JULY

    private void updateUI() {


        progressDialog.dismiss();
        final UserModel userModel = new UserModel(nameEdit.getText().toString(),emailEdit.getText().toString(),phoneEdit.getText().toString(),addressEdit.getText().toString(),imgUrl,mAuth.getUid());

        DatabaseReference mDatabaseForInstance = FirebaseDatabase.getInstance().getReference().child("AccountType");
        mDatabaseForInstance.child(mAuth.getCurrentUser().getUid()).setValue("User").addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo");
                mDatabaseForManagement.child("Users").child(mAuth.getCurrentUser().getUid()).setValue(userModel).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        MDToast.makeText(SignUpActivity.this, "Successfully Registered", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
                        GuestDetailsStatic.Gname="";
                        GuestDetailsStatic.Gphno="";
                        GuestDetailsStatic.Gmail="";
                        GuestDetailsStatic.Gaddr="";
                        startActivity(new Intent(SignUpActivity.this, SelectionActivity.class));
                        finish();
                    }
                });
            }
        });


    }

    private boolean isEmailvalid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void getting_userImage() {

        Register_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                ask_for_image();
            }
        });
    }
    public void ask_for_image() {
        CropImage.activity()
                .setAspectRatio(1, 1).start(SignUpActivity.this);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        final CropImage.ActivityResult result = CropImage.getActivityResult(data);
        if (resultCode == RESULT_OK) {
            Image_uri = result.getUri();

            Glide.with(SignUpActivity.this).load(Image_uri).into(Register_image);
        }

    }


}
