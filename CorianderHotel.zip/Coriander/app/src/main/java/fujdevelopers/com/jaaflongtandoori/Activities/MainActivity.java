package fujdevelopers.com.jaaflongtandoori.Activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.valdesekamdem.library.mdtoast.MDToast;
import com.viewpagerindicator.CirclePageIndicator;
import com.wang.avi.AVLoadingIndicatorView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Adapter.CatAdapter;
import fujdevelopers.com.jaaflongtandoori.Adapter.ViewPager_Adapter;
import fujdevelopers.com.jaaflongtandoori.Database.CartDbHelper;
import fujdevelopers.com.jaaflongtandoori.Model.CartProductModel;
import fujdevelopers.com.jaaflongtandoori.Model.CatModel;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class MainActivity extends AppCompatActivity {

    RecyclerView categoriesRecycler;
    CatAdapter adapter;

    List<CatModel> list = new ArrayList<>();

    AVLoadingIndicatorView avi;
    //Drawer
    private DrawerLayout drawerLayout;
    private ImageView imageView;
    private NavigationView navigationView;
    TextView header_name;
    CircleImageView header_image;

    //ViewPager
    private static ViewPager mPager;
    private ArrayList<Integer> ImagesArray = new ArrayList<>();
    private ViewPager_Adapter viewPager_adapter;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;

    ImageView cartImage;
    FirebaseAuth mAuth;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        findViewById(R.id.book).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,BookReservationActivity.class));
            }
        });

        final TextView nottext=findViewById(R.id.nottext);
        nottext.setVisibility(View.GONE);
        FirebaseDatabase.getInstance().getReference().child("message").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Log.d("DSP",dataSnapshot.toString());
                nottext.setText(dataSnapshot.getValue().toString());
                if(nottext.getText().equals(""))
                    nottext.setVisibility(View.GONE);
                else
                    nottext.setVisibility(View.VISIBLE);
/*
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    text.setText(ds.getValue().toString());
                }
*/

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        if(!GuestDetailsStatic.Gname.equals("")){
            startActivity(new Intent(MainActivity.this,CartActivity.class));
        }

        avi = findViewById(R.id.avi_all_cat);
        mAuth = FirebaseAuth.getInstance();

        mPager = findViewById(R.id.pager);
        ImagesArray.add(R.drawable.long_logo);
//        ImagesArray.add(R.drawable.chcikenlambtikka);
        ImagesArray.add(R.drawable.chickenlambbalti);
        ImagesArray.add(R.drawable.chickenlambbaryani);

        Toast.makeText(MainActivity.this,"We are offering you, Order now, take later",Toast.LENGTH_LONG).show();



        categoriesRecycler = findViewById(R.id.categories_recyclers);
        adapter = new CatAdapter(list, this);
        categoriesRecycler.setAdapter(adapter);
        categoriesRecycler.setLayoutManager(new LinearLayoutManager(this));
        getData();
        Navigation_Drawe();



        cartImage = findViewById(R.id.cart_btn_main);

        cartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!GuestDetailsStatic.Gname.equals("")){
                    startActivity(new Intent(MainActivity.this, CartActivity.class));
                }
                else{
                    if (mAuth.getCurrentUser()!=null){
                        startActivity(new Intent(MainActivity.this, CartActivity.class));

                    }
                    else {
                        startActivity(new Intent(getApplicationContext(),LogInActivity.class));
                        finish();
                        Toast.makeText(MainActivity.this, "To Place Order LogIn First", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });




        init();
    }

    private void init() {


        viewPager_adapter = new ViewPager_Adapter(MainActivity.this, ImagesArray);
        mPager.setAdapter(viewPager_adapter);
        CirclePageIndicator indicator =
                findViewById(R.id.indicator);

        indicator.setViewPager(mPager);

        final float density = getResources().getDisplayMetrics().density;

//Set circle indicator radius
        indicator.setRadius(3 * density);

        NUM_PAGES = ImagesArray.size();

        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };

        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                currentPage = position;

            }

            @Override
            public void onPageScrolled(int pos, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int pos) {

            }
        });


    }


    private void Navigation_Drawe(){

        imageView = findViewById(R.id.menu_icon);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);


        View header = navigationView.getHeaderView(0);

        header_name = header.findViewById(R.id.name_header);
        header_image = header.findViewById(R.id.imageView_header);


        if (mAuth.getCurrentUser()!=null){
            DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(mAuth.getCurrentUser().getUid());
            mDatabaseForManagement.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    UserModel userModel = dataSnapshot.getValue(UserModel.class);
                    header_name.setText(userModel.getUser_name());
                    Picasso.get()
                            .load(userModel.getUser_image())
                            .into(header_image);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
        else {
            header_name.setText("Guest User");
            Picasso.get()
                    .load(R.drawable.cooking)
                    .into(header_image);



        }





        ImageListener();
        NavigationListener();
    }

    private void ImageListener() {
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    private void NavigationListener() {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                int itemId = menuItem.getItemId();
                drawerLayout.closeDrawer(GravityCompat.START);

                switch (itemId) {

                    case R.id.home:
                        try {
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                        } catch (Exception e) {
                        }
                        break;

                    case R.id.order_history:

                        if (mAuth.getCurrentUser() == null){
                            startActivity(new Intent(getApplicationContext(),LogInActivity.class));
                            finish();

                        }
                        else {
                            startActivity(new Intent(getApplicationContext(),OrderHistory.class));

                        }
                        break;

                    case R.id.share:
                        try {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("text/plain");
                            i.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                            final String appPackageName = getPackageName();
                            String Company_Data = "Try This Awesome App At \n" + "https://play.google.com/store/apps/details?id=" + appPackageName;
                            i.putExtra(Intent.EXTRA_TEXT, Company_Data);
                            startActivity(Intent.createChooser(i, "choose one"));
                        } catch (Exception e) {
                        }
                        break;
                    case R.id.nav_Rate:
                        Uri uri = Uri.parse("market://details?id=" + MainActivity.this.getPackageName());
                        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                        try {
                            startActivity(goToMarket);
                        } catch (ActivityNotFoundException e) {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("http://play.google.com/store/apps/details?id=" + MainActivity.this.getPackageName())));
                        }
                        break;

                    case R.id.nav_signout:

                        if (mAuth.getCurrentUser()!=null){
                            mAuth.signOut();
                            Intent intent = new Intent(MainActivity.this, LogInActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            finish();
                        }
                        else {
                            Intent intent = new Intent(MainActivity.this, LogInActivity.class);
                            startActivity(intent);
                            finish();

                            Toast.makeText(MainActivity.this, "You are Not Logged In", Toast.LENGTH_SHORT).show();
                        }

                        break;

                }


                return false;
            }
        });

    }


    private void getData() {
        Log.d("LOGGING","INSIDE GET DATA: ");
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Categories");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                Log.d("LOGGING","INSIDE GET DATA: ON DATA CHANGE");


                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    CatModel catModel = d.getValue(CatModel.class);

                    list.add(catModel);
                }
                avi.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("LOGGING","INSIDE GET DATA: ON CANCELLED");

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        CartDbHelper dbHelper  = new CartDbHelper(this);

        String item_np = String.valueOf(dbHelper.getAllItems().size());

        TextView cart_item_no =  findViewById(R.id.cart_items_number);
        if (dbHelper.getAllItems().size() >0){

            cart_item_no.setVisibility(View.VISIBLE);
            cart_item_no.setText(item_np);
        }
        else {
            cart_item_no.setVisibility(View.GONE);
        }


    }

}
