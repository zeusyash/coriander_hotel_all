package fujdevelopers.com.jaaflongtandoori.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.R;

public class GuestDetailsStatic  {

    public static String Gname="";
    public static String Gaddr="";
    public static String Gphno="";
    public static String Gmail="";

}