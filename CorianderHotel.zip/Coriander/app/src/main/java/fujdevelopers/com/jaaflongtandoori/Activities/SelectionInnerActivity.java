package fujdevelopers.com.jaaflongtandoori.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import fujdevelopers.com.jaaflongtandoori.Model.CartProductModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class SelectionInnerActivity extends AppCompatActivity {

    RadioGroup restaurantG, typeG, tableG;
    RadioButton centralR, southernR, deliveryR, takeawayR, oftableR, oneR, twoR, threeR, fourR;
    LinearLayout tablesLay;
    Button continueBtn;


    public static String restaurant="";
    public static String type="";

    List<CartProductModel> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_inner);

        restaurant=SelectionActivity.restaurant;

        list = (List<CartProductModel>) getIntent().getSerializableExtra("Orders");


        continueBtn=findViewById(R.id.continueBtn_payment);
        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
/*
                if(centralR.isChecked())
                    restaurant="Corriander Central Chorlton";
                if(southernR.isChecked())
                    restaurant="Corriander Southern Cemetery";
*/
                if(takeawayR.isChecked())
                    type="Takeaway";
                if(deliveryR.isChecked())
                    type="Delivery";
                if(oftableR.isChecked()){
                    if(oneR.isChecked())
                        type="Table No : 1";
                    if(twoR.isChecked())
                        type="Table No : 2";
                    if(threeR.isChecked())
                        type="Table No : 3";
                    if(fourR.isChecked())
                        type="Table No : 4";
                }



                Toast.makeText(SelectionInnerActivity.this,restaurant+" "+type,Toast.LENGTH_SHORT).show();
//                startActivity(new Intent(SelectionActivity.this, PaymentMethodActivity.class).putExtra("Orders", (Serializable) list));
                startActivity(new Intent(SelectionInnerActivity.this, PaymentMethodActivity.class).putExtra("Orders", (Serializable) list));

            }
        });

        tablesLay=findViewById(R.id.tablelayout);
        tablesLay.setVisibility(View.GONE);

        restaurantG=findViewById(R.id.restaurant);
        typeG=findViewById(R.id.type);
        tableG=findViewById(R.id.tables);

        centralR=findViewById(R.id.central);
        southernR=findViewById(R.id.southern);

        deliveryR=findViewById(R.id.delivery);
        takeawayR=findViewById(R.id.takeaway);
        oftableR=findViewById(R.id.order_from_table);

        oneR=findViewById(R.id.one);
        twoR=findViewById(R.id.two);
        threeR=findViewById(R.id.three);
        fourR=findViewById(R.id.four);



        oftableR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    tablesLay.setVisibility(View.VISIBLE);
                else
                    tablesLay.setVisibility(View.GONE);
            }
        });

    }



}
