package fujdevelopers.com.jaaflongtandoori.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import fujdevelopers.com.jaaflongtandoori.Model.CancelModel;
import fujdevelopers.com.jaaflongtandoori.R;


public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.ViewHolder> {

    List<CancelModel> list;
    Context context;

    public OrdersAdapter(List<CancelModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public OrdersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrdersAdapter.ViewHolder holder, final int position) {

        final CancelModel model = list.get(position);


        holder.address.setText(model.getAdresss());
        holder.ordebill.setText(model.getTotal_price());
        holder.detail_order.setText(model.getOrder_detail());
        holder.no.setText(model.getOrderno());
        String date_order = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(model.getOrdertime());

            date_order = formatter.format(calendar.getTime());

        } catch (Exception e) {

        }

        holder.order_time.setText(date_order);

        holder.status.setOnClickListener(null);

        if (model.getStatus().equals("New")){
            holder.status.setText("Order Status : " + "Not Approved");
        }
        else {
            holder.status.setText("Order Status : " +model.getStatus());
        }




//        long order_time = model.getOrdertime() + 900000;
//        if (System.currentTimeMillis() >= order_time) {
//
//            holder.timer_layout.setVisibility(View.GONE);
//        } else {
//            holder.timer_layout.setVisibility(View.VISIBLE);

//            holder.cancelorder.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//                    Log.d("Checking Order", "dasdasdasdasdas  " + model.getOrderno());
//
//                    DatabaseReference mDatabaseForCancel = FirebaseDatabase.getInstance().getReference().child("Orders").child(model.getOrderno());
//                    mDatabaseForCancel.child("Status").setValue("Canceled");
//                    context.startActivity(new Intent(context, context.getClass()));
//
//
//                }
//            });

//        }

//        SettingTimer(model.getOrdertime(),holder);


    }

//    private void SettingTimer(long ordertime, ViewHolder holder) {
//
//
//        long curr = ordertime + 900000;
//        if (System.currentTimeMillis() < curr) {
//
//            long timer = curr - System.currentTimeMillis();
//
//
////            Countdown(timer,holder);
//
//
//        }
//
//
//    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView address, ordebill, detail_order, order_time, no, Timer, cancelorder;
        private Button status;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            no = itemView.findViewById(R.id.Order_No);
            detail_order = itemView.findViewById(R.id.order_detail);
            address = itemView.findViewById(R.id.order_address);
            order_time = itemView.findViewById(R.id.order_time);
            ordebill = itemView.findViewById(R.id.total_price);
            status = itemView.findViewById(R.id.status);

        }
    }

//    private void Countdown(long timer, final ViewHolder holder) {
//
//        CountDownTimer count = new CountDownTimer(timer, 1000) {
//            @Override
//            public void onTick(long millisUntilFinished) {
//
//                long secondsInMilli = 1000;
//                long minutesInMilli = secondsInMilli * 60;
//
//
//                long elapsedMinutes = millisUntilFinished / minutesInMilli;
//                millisUntilFinished = millisUntilFinished % minutesInMilli;
//
//                long elapsedSeconds = millisUntilFinished / secondsInMilli;
//
//
//                String yy = String.format("%02d:%02d", elapsedMinutes, elapsedSeconds);
//                holder.Timer.setText(yy);
//
//                Calendar calendar = Calendar.getInstance();
//
//
//
//            }
//
//            @Override
//            public void onFinish() {
//                holder.timer_layout.setVisibility(View.GONE);
//            }
//
//
//        }.start();
//
//
//    }


}
