package fujdevelopers.com.jaaflongtandoori.Model;

import java.io.Serializable;

public class CartProductModel implements Serializable {

    private int Id;
    private int quantity;
    private String catId;
    private String catName;
    private String productId;
    private String productName;
    private String productImage;
    private String productDiscription;
    private String productPrice;

    public String getShortdescr() {
        return shortdescr;
    }

    public void setShortdescr(String shortdescr) {
        this.shortdescr = shortdescr;
    }

    private String shortdescr;


    public CartProductModel() {
    }

    public CartProductModel(int id, int quantity, String catId, String catName, String productId, String productName, String productImage, String productDiscription, String productPrice,String shortdescr) {
        Id = id;
        this.quantity = quantity;
        this.catId = catId;
        this.catName = catName;
        this.productId = productId;
        this.productName = productName;
        this.productImage = productImage;
        this.productDiscription = productDiscription;
        this.productPrice = productPrice;
        this.shortdescr = shortdescr;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getProductDiscription() {
        return productDiscription;
    }

    public void setProductDiscription(String productDiscription) {
        this.productDiscription = productDiscription;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }
}
