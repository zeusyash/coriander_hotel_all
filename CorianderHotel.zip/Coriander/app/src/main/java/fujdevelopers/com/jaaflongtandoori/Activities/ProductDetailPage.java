package fujdevelopers.com.jaaflongtandoori.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Database.CartDbHelper;
import fujdevelopers.com.jaaflongtandoori.Model.CartProductModel;
import fujdevelopers.com.jaaflongtandoori.Model.ProductModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class ProductDetailPage extends AppCompatActivity {


    ProductModel productModel;

    DatabaseReference mDatabaseForProductUploading;

    String Selected_Category_ID;
    String Selected_Category_Name;

    private TextView Category_Name_View;
    TextView productName, productPrice, productDisc;
    EditText shorttext;
    ImageView productImage;
    Button AddToCart;
    ProgressDialog progressDialog;


    private RecyclerView reviewsrecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail_page);


        productModel = (ProductModel) getIntent().getSerializableExtra("Product");


        Category_Name_View = findViewById(R.id.Category_View_Id);
        Category_Name_View.setText(productModel.getCatName());

        reviewsrecyclerView = findViewById(R.id.reviews);
        reviewsrecyclerView.setLayoutManager(new LinearLayoutManager(this));




        initViews();

    }

    private void initViews() {

        mDatabaseForProductUploading = FirebaseDatabase.getInstance().getReference().child("Categories").child(productModel.getCatId()).child("Products");


        Selected_Category_ID = productModel.getCatId();
        Selected_Category_Name = productModel.getCatName();

        progressDialog = new ProgressDialog(this);

        shorttext = findViewById(R.id.shortText);
        productName = findViewById(R.id.product_name_edit_add);
        productName.setText(productModel.getProductName());
        productPrice = findViewById(R.id.product_price_edit_add);
        productPrice.setText("\u00a3" + productModel.getProductPrice());
        productDisc = findViewById(R.id.product_disc_edit_add);
        productDisc.setText(productModel.getProductDiscription());
        productImage = findViewById(R.id.product_image_add);
        Glide.with(this).load(productModel.getProductImage()).into(productImage);
//        productImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                CropImage.activity()
//                        .setAspectRatio(1, 1)
//                        .start(ProductDetailPage.this);
//            }
//        });
        AddToCart = findViewById(R.id.add_product_btn);
        AddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                add_toCardDialog(productModel);


            }
        });


    }

    int number = 1;

    private void add_toCardDialog(final ProductModel model) {

        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        //setting up the layout for alert dialog
        View view1 = LayoutInflater.from(this).inflate(R.layout.add_to_cart_dialog, null, false);

        builder1.setView(view1);


//        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("User").child(mAuth.getCurrentUser().getUid());
//        mDatabase.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                if (dataSnapshot.hasChild("Favourites")){
//                    if (dataSnapshot.child("Favourites").hasChild(model.getProductId())){
//                        favImageBtn.setImageResource(R.drawable.ic_favorite_black_24dp);
//                    } else {
//                        favImageBtn.setImageResource(R.drawable.ic_favorite_border_orange_24dp);
//                    }
//                } else {
//                    favImageBtn.setImageResource(R.drawable.ic_favorite_border_orange_24dp);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });

        TextView foodDisc = view1.findViewById(R.id.food_disc_dialog);
        foodDisc.setText(model.getProductDiscription());

        TextView foodName = view1.findViewById(R.id.food_name_dialog);
        foodName.setText(model.getProductName());
        TextView foodPrice = view1.findViewById(R.id.food_price_food_dialog);
        foodPrice.setText( "\u00a3" +" "+ model.getProductPrice());
        ImageView foodImage = view1.findViewById(R.id.food_image_add_card_dialog);
        Glide.with(ProductDetailPage.this).load(model.getProductImage()).into(foodImage);
        final TextView quantity_text = view1.findViewById(R.id.quantity_text);
        ImageView addBtn = view1.findViewById(R.id.add_quantity);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number++;
                quantity_text.setText(String.valueOf(number));
            }
        });

        ImageView minusBtn = view1.findViewById(R.id.remove_quantity);
        Button addToCartBtn = view1.findViewById(R.id.add_toCartFinal);
        Button cancelBtn = view1.findViewById(R.id.cancel_btn_dialog);

        final AlertDialog dialogg = builder1.create();
        dialogg.show();

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = 1;
                dialogg.cancel();
            }
        });

        minusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ne = number--;
                if (ne <= 1) {
                    number++;
                } else {
                    quantity_text.setText(String.valueOf(number));
                }
            }
        });

        addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCart(model);
                dialogg.dismiss();


            }
        });
    }

    private void addToCart(ProductModel model) {
        CartProductModel cartProductModel = new CartProductModel();

        cartProductModel.setProductId(model.getProductId());
        cartProductModel.setProductName(model.getProductName());
        cartProductModel.setProductImage(model.getProductImage());
        cartProductModel.setProductDiscription(model.getProductDiscription());
        cartProductModel.setProductPrice(model.getProductPrice());
        cartProductModel.setCatId(model.getCatId());
        cartProductModel.setCatName(model.getCatName());
        cartProductModel.setQuantity(number);

        if(shorttext.getText().toString().isEmpty())
        cartProductModel.setShortdescr(" ");
        else
        cartProductModel.setShortdescr(shorttext.getText().toString());


        CartDbHelper dbHelper = new CartDbHelper(ProductDetailPage.this);
        double response = dbHelper.insertItem(cartProductModel);
        if (response == -1) {
            MDToast.makeText(ProductDetailPage.this, "Not Added", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
        } else {


            MDToast.makeText(ProductDetailPage.this, "Added to Cart.", MDToast.LENGTH_LONG, MDToast.TYPE_SUCCESS).show();
        }
    }

    public void onClickBackItem(View view) {
        onBackPressed();
    }



}
