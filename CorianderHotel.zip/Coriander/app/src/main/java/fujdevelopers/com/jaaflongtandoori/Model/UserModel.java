package fujdevelopers.com.jaaflongtandoori.Model;

public class UserModel {

    private String user_name;
    private String user_email;
    private String user_address;
    private String user_image;
    private String user_id;

    public String getPhno() {
        return phno;
    }

    public void setPhno(String phno) {
        this.phno = phno;
    }

    private String phno;
    public UserModel() {
    }

    public UserModel(String user_name, String user_email, String phno, String user_address, String user_image, String user_id) {
        this.user_name = user_name;
        this.user_email = user_email;
        this.user_address = user_address;
        this.phno = phno;
        this.user_image = user_image;
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_address() {
        return user_address;
    }

    public void setUser_address(String user_address) {
        this.user_address = user_address;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }
}
