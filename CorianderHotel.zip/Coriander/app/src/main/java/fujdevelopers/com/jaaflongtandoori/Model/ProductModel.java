package fujdevelopers.com.jaaflongtandoori.Model;

import java.io.Serializable;

public class ProductModel implements Serializable {

    private String catId, catName, productId, productName, productImage, productDiscription, productPrice;

    public ProductModel(String catId, String catName, String productId, String productName, String productImage, String productDiscription, String productPrice) {
        this.catId = catId;
        this.catName = catName;
        this.productId = productId;
        this.productName = productName;
        this.productImage = productImage;
        this.productDiscription = productDiscription;
        this.productPrice = productPrice;
    }

    public ProductModel() {
    }

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getProductDiscription() {
        return productDiscription;
    }

    public void setProductDiscription(String productDiscription) {
        this.productDiscription = productDiscription;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }
}

