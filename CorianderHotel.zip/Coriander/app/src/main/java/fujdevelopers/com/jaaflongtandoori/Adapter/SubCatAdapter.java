package fujdevelopers.com.jaaflongtandoori.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import fujdevelopers.com.jaaflongtandoori.Activities.ProductsActivity;
import fujdevelopers.com.jaaflongtandoori.Activities.SubProductsActivity;
import fujdevelopers.com.jaaflongtandoori.Model.CatModel;
import fujdevelopers.com.jaaflongtandoori.R;


public class SubCatAdapter extends RecyclerView.Adapter<SubCatAdapter.ViewHolder> {

    List<CatModel> list;
    Context context;

    public SubCatAdapter(List<CatModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public SubCatAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.cat_card, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SubCatAdapter.ViewHolder holder, int position) {

        final CatModel model = list.get(position);

        holder.catName.setText(model.getCatName());

        Glide.with(context).load(model.getCatImage()).into(holder.catImage);

        holder.bgCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    context.startActivity(new Intent(context, SubProductsActivity.class).putExtra("Category", model));
//
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView catName;
        ImageView catImage;

        CardView bgCard;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            catName = itemView.findViewById(R.id.cat_name_cat_card);
            catImage = itemView.findViewById(R.id.cat_image_cat_card);

            bgCard = itemView.findViewById(R.id.cat_bg_card);
        }
    }
}
