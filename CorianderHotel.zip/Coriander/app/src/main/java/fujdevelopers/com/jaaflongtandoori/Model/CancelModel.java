package fujdevelopers.com.jaaflongtandoori.Model;

public class CancelModel {

    private String order_detail,total_price,adresss,orderno,status;
    private long ordertime;

    public CancelModel() {
    }

    public CancelModel(String order_detail, String total_price, String adresss, String orderno, String status, long ordertime) {
        this.order_detail = order_detail;
        this.total_price = total_price;
        this.adresss = adresss;
        this.orderno = orderno;
        this.status = status;
        this.ordertime = ordertime;
    }

    public String getOrder_detail() {
        return order_detail;
    }

    public void setOrder_detail(String order_detail) {
        this.order_detail = order_detail;
    }

    public String getTotal_price() {
        return total_price;
    }

    public void setTotal_price(String total_price) {
        this.total_price = total_price;
    }

    public String getAdresss() {
        return adresss;
    }

    public void setAdresss(String adresss) {
        this.adresss = adresss;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(long ordertime) {
        this.ordertime = ordertime;
    }
}
