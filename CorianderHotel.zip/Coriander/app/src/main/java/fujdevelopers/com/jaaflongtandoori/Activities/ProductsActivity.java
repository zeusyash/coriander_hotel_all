package fujdevelopers.com.jaaflongtandoori.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.wang.avi.AVLoadingIndicatorView;

import java.util.ArrayList;
import java.util.List;

import fujdevelopers.com.jaaflongtandoori.Adapter.CartAdapter;
import fujdevelopers.com.jaaflongtandoori.Adapter.CatAdapter;
import fujdevelopers.com.jaaflongtandoori.Adapter.ProductAdapter;
import fujdevelopers.com.jaaflongtandoori.Adapter.SubCatAdapter;
import fujdevelopers.com.jaaflongtandoori.Database.CartDbHelper;
import fujdevelopers.com.jaaflongtandoori.Model.CatModel;
import fujdevelopers.com.jaaflongtandoori.Model.ProductModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class ProductsActivity extends AppCompatActivity {

    RecyclerView productsRecycler;
    RecyclerView subrecycler;
    ProductAdapter adapter;
    SubCatAdapter subcatadapter;

    CatModel catModel;

    DatabaseReference mDatabaseForGettingProducts;

    List<ProductModel> list = new ArrayList<>();
    List<CatModel> sublist = new ArrayList<>();

    AVLoadingIndicatorView avi;
    TextView heading;

    FirebaseAuth mAuth;

    ImageView cartImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);


        catModel = (CatModel) getIntent().getSerializableExtra("Category");
        heading = findViewById(R.id.heading);
        heading.setText(catModel.getCatName());

        mAuth = FirebaseAuth.getInstance();


        cartImage = findViewById(R.id.cart_btn_main);

        cartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mAuth.getCurrentUser()!=null){
                    startActivity(new Intent(getApplicationContext(), CartActivity.class));

                }
                else {
                    startActivity(new Intent(getApplicationContext(),LogInActivity.class));
                    finish();
                    Toast.makeText(getApplicationContext(), "To Place Order LogIn First", Toast.LENGTH_SHORT).show();
                }                }
        });
        initViews();
    }


    private void initViews() {
        avi = findViewById(R.id.avi_all_product);
        productsRecycler = findViewById(R.id.products_recycler);
        adapter = new ProductAdapter(list, this);
        productsRecycler.setAdapter(adapter);
        productsRecycler.setLayoutManager(new LinearLayoutManager(this));

        subrecycler = findViewById(R.id.subcat_recycler);
        subcatadapter = new SubCatAdapter(sublist, this);
        subrecycler.setAdapter(subcatadapter);
        subrecycler.setLayoutManager(new LinearLayoutManager(this));

        getDataProduct();
        getDataSubcat();
    }

    private void getDataProduct() {
        mDatabaseForGettingProducts = FirebaseDatabase.getInstance().getReference().child("Categories").child(catModel.getCatId()).child("Products");
        mDatabaseForGettingProducts.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();

                for (DataSnapshot d : dataSnapshot.getChildren()) {

                    ProductModel productModel = d.getValue(ProductModel.class);
//                    String productName = d.child("ProductName").getValue().toString();
//                    String productId = d.child("ProductId").getValue().toString();
//                    String productImage = d.child("ProductImage").getValue().toString();
//                    String productDisc = d.child("ProductDisc").getValue().toString();
//                    String productPrice = d.child("ProductPrice").getValue().toString();
//                    String catId = d.child("CategoryId").getValue().toString();
//                    String catName = d.child("CategoryName").getValue().toString();

//                    list.add(new ProductModel(catId, catName, productId, productName, productImage, productDisc, productPrice));

                    list.add(productModel);

                }
                avi.setVisibility(View.GONE);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    private void getDataSubcat() {
        Log.d("LOGGING","INSIDE GET DATA: ");
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Categories").child(catModel.getCatId()).child("Subcat");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                sublist.clear();
                Log.d("LOGGING","INSIDE GET DATA: ON DATA CHANGE");


                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    CatModel catModel = d.getValue(CatModel.class);


                    sublist.add(catModel);
                }
                avi.setVisibility(View.GONE);
                subcatadapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("LOGGING","INSIDE GET DATA: ON CANCELLED");

            }
        });
    }

    public void onClickBackItem(View view) {
        onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        CartDbHelper dbHelper = new CartDbHelper(this);

        String item_np = String.valueOf(dbHelper.getAllItems().size());

        TextView cart_item_no = findViewById(R.id.cart_items_number);
        if (dbHelper.getAllItems().size() > 0) {

            cart_item_no.setVisibility(View.VISIBLE);
            cart_item_no.setText(item_np);
        } else {
            cart_item_no.setVisibility(View.GONE);
        }


    }

}
