package fujdevelopers.com.jaaflongtandoori.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.FileNotFoundException;
import java.io.InputStream;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class GuestOrderActivity extends AppCompatActivity {

    EditText emailEdit, paswordEdit, nameEdit, addressEdit, phoneEdit;
    Button registerBtn;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;
    private CircleImageView Register_image;
    private Uri Image_uri;
    private String imgUrl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_order);


        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);


        phoneEdit = findViewById(R.id.phone_edit_register);
        emailEdit = findViewById(R.id.email_edit_register);
        paswordEdit = findViewById(R.id.password_edit_register);
        nameEdit = findViewById(R.id.name_edit_register);
        addressEdit = findViewById(R.id.address_edit_register);
        Register_image = findViewById(R.id.user_image);


        registerBtn = findViewById(R.id.register_btn_register);


        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(phoneEdit.getText().length()<11){
                    MDToast.makeText(GuestOrderActivity.this, "Please enter correct phone number", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (emailEdit.getText().toString().isEmpty() || nameEdit.getText().toString().isEmpty() || addressEdit.getText().toString().isEmpty() || phoneEdit.getText().toString().isEmpty() ){
                    MDToast.makeText(GuestOrderActivity.this, "Please fill all the fields above first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                if (!isEmailvalid(emailEdit.getText().toString())) {
                    MDToast.makeText(GuestOrderActivity.this, "Email is not valid", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                Intent intent = new Intent(GuestOrderActivity.this, MainActivity.class);
                 GuestDetailsStatic.Gname= nameEdit.getText().toString();
                 GuestDetailsStatic.Gmail=emailEdit.getText().toString();
                 GuestDetailsStatic.Gaddr= addressEdit.getText().toString();
                 GuestDetailsStatic.Gphno=phoneEdit.getText().toString();

                 CartActivity.editname=GuestDetailsStatic.Gname;
                 CartActivity.editaddress=GuestDetailsStatic.Gaddr;



                startActivity(intent);
                finish();
            }

        });

    }

    private boolean isEmailvalid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }


}