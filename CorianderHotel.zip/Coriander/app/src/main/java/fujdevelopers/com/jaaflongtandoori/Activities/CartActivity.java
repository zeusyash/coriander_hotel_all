package fujdevelopers.com.jaaflongtandoori.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.valdesekamdem.library.mdtoast.MDToast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Adapter.CartAdapter;
import fujdevelopers.com.jaaflongtandoori.Database.CartDbHelper;
import fujdevelopers.com.jaaflongtandoori.Model.CartProductModel;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class CartActivity extends AppCompatActivity {

//
//    //Drawer
//    private DrawerLayout drawerLayout;
//    private ImageView imageView;
//    private NavigationView navigationView;
//    TextView header_name;
//    CircleImageView header_image;


    public static TextView totalPriceTextCart;
    public static String totalPriceTextCar;
    public static double total;

    RecyclerView recyclerView;
    CartAdapter adapter;
    List<CartProductModel> list = new ArrayList<>();

    CartDbHelper dbHelper;
    FirebaseAuth mAuth;
    public static String editname,editaddress,phno,email;



    //setting and getting main activity
    private static CartActivity cartActivity;

    public static CartActivity getCartActivity() {
        return cartActivity;
    }

    private static void setCartActivity(CartActivity cartActivity) {
        CartActivity.cartActivity = cartActivity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);



        if(!GuestDetailsStatic.Gname.equals("")){
//            Toast.makeText(CartActivity.this,"GNAME: "+GuestDetailsStatic.Gname,Toast.LENGTH_SHORT).show();
        }

        mAuth = FirebaseAuth.getInstance();
        CartActivity.setCartActivity(this);



        if(GuestDetailsStatic.Gname.equals(""))
            GetUserData();


//        Navigation_Drawer();

        dbHelper = new CartDbHelper(this);

        totalPriceTextCart = findViewById(R.id.total_price_text_cart);

        recyclerView = findViewById(R.id.cart_recycler);
        adapter = new CartAdapter(list, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        findViewById(R.id.add_more_cart_act).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.continueBtn_cart_act).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (list.size() > 0) {
                    startActivity(new Intent(CartActivity.this, SelectionInnerActivity.class).putExtra("Orders", (Serializable) list));
                } else {
                    MDToast.makeText(CartActivity.this, "You don't have any item in your cart to Continue.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                }
            }
        });



    }

    private void GetUserData() {

            DatabaseReference userDataRef = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(mAuth.getCurrentUser().getUid());
            userDataRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    editname = dataSnapshot.child("user_name").getValue().toString();
                    editaddress =dataSnapshot.child("user_address").getValue().toString();
                    email =dataSnapshot.child("user_email").getValue().toString();
                    phno =dataSnapshot.child("phno").getValue().toString();



                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

    }












    @Override
    protected void onResume() {
        super.onResume();

        list.clear();
        total = 0;
        List<CartProductModel> models = new ArrayList<>(dbHelper.getAllItems());

        for (CartProductModel mod : models) {
            list.add(mod);

                total = total + (mod.getQuantity() * Double.parseDouble(mod.getProductPrice()));

        }

        String formattedValue = String.format("%.2f", total);


        totalPriceTextCar =  formattedValue;
        totalPriceTextCart.setText("\u00a3"+ " " + String.valueOf(total));
        adapter.notifyDataSetChanged();
    }

    public void recallOnResume() {
        onResume();
    }




//
//
//    private void Navigation_Drawer(){
//
//        imageView = findViewById(R.id.menu_icon);
//        drawerLayout = findViewById(R.id.drawer_layout);
//        navigationView = findViewById(R.id.nav_view);
//
//
//
//        View header = navigationView.getHeaderView(0);
//
//        header_name = header.findViewById(R.id.name_header);
//        header_image = header.findViewById(R.id.imageView_header);
//
//
//        DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(mAuth.getCurrentUser().getUid());
//        mDatabaseForManagement.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                UserModel userModel = dataSnapshot.getValue(UserModel.class);
//                header_name.setText(userModel.getUser_name());
//                Picasso.get()
//                        .load(userModel.getUser_image())
//                        .into(header_image);
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//
//
//
//        ImageListener();
//        NavigationListener();
//    }
//
//    private void ImageListener() {
//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                drawerLayout.openDrawer(GravityCompat.START);
//            }
//        });
//    }
//
//    private void NavigationListener() {
//        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
//            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//
//                int itemId = menuItem.getItemId();
//                drawerLayout.closeDrawer(GravityCompat.START);
//
//                switch (itemId) {
//
//                    case R.id.home:
//                        try {
//                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
//                            finish();
//                        } catch (Exception e) {
//                        }
//                        break;
//
//                    case R.id.order_history:
//                        startActivity(new Intent(getApplicationContext(),OrderHistory.class));
//
//                        break;
//
//                    case R.id.privacy_policy:
//
//                        break;
//                    case R.id.share:
//                        try {
//                            Intent i = new Intent(Intent.ACTION_SEND);
//                            i.setType("text/plain");
//                            i.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
//                            final String appPackageName = getPackageName();
//                            String Company_Data = "Try This Awesome App At \n" + "https://play.google.com/store/apps/details?id=" + appPackageName;
//                            i.putExtra(Intent.EXTRA_TEXT, Company_Data);
//                            startActivity(Intent.createChooser(i, "choose one"));
//                        } catch (Exception e) {
//                        }
//                        break;
//                    case R.id.nav_Rate:
//                        Uri uri = Uri.parse("market://details?id=" + getApplicationContext().getPackageName());
//                        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
//                        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
//                                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
//                                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
//                        try {
//                            startActivity(goToMarket);
//                        } catch (ActivityNotFoundException e) {
//                            startActivity(new Intent(Intent.ACTION_VIEW,
//                                    Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
//                        }
//                        break;
//
//                    case R.id.nav_signout:
//                        mAuth.signOut();
//                        Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
//                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        startActivity(intent);
//                        finish();
//                        break;
//
//                }
//
//
//                return false;
//            }
//        });
//
//    }

    public void onClickBackItem(View view) {
        onBackPressed();
    }

}
