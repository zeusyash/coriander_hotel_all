package fujdevelopers.com.jaaflongtandoori.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import fujdevelopers.com.jaaflongtandoori.Adapter.OrdersAdapter;
import fujdevelopers.com.jaaflongtandoori.Database.CartDbHelper;
import fujdevelopers.com.jaaflongtandoori.Model.CancelModel;
import fujdevelopers.com.jaaflongtandoori.Model.CartProductModel;
import fujdevelopers.com.jaaflongtandoori.Model.UserModel;
import fujdevelopers.com.jaaflongtandoori.R;

public class OrderHistory extends AppCompatActivity {



    public static String assignedWorkerId = "";
    public static String addressString = "";

    TextView orderNumberText;

    LinearLayout ordersLayout;
    TextView emptyOrders;
    ImageView cartImage;


    RecyclerView OrdersRecycler;
    OrdersAdapter ordersAdapter;
    List<CartProductModel> list = new ArrayList<>();

    public static String status = "";
    public static String orderId = "";
    private ArrayList<CancelModel> cancel_list = new ArrayList<>();
    private ArrayList<String> orderno_list = new ArrayList<>();

    //Drawer
    private DrawerLayout drawerLayout;
    private ImageView imageView;
    private NavigationView navigationView;
    TextView header_name;
    CircleImageView header_image;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);


        mAuth = FirebaseAuth.getInstance();
        Navigation_Drawer();
        initView();

        cartImage = findViewById(R.id.cart_btn_main);

        cartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(OrderHistory.this, CartActivity.class));
            }
        });

    }









    private void initView() {


        ordersLayout = findViewById(R.id.orders_layout_my_order);
        ordersLayout.setVisibility(View.VISIBLE);

        OrdersRecycler = findViewById(R.id.order_recycler);

        OrdersRecycler.setLayoutManager(new LinearLayoutManager(this));
        ordersAdapter = new OrdersAdapter(cancel_list, OrderHistory.this);
        OrdersRecycler.setAdapter(ordersAdapter);

        findViewById(R.id.cart_btn_main).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(OrderHistory.this, CartActivity.class));
            }
        });


        getData();
    }

    private void getData() {

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("Orders");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    try {
                        if (d.child("UserId").getValue().toString().equals(mAuth.getCurrentUser().getUid())) {
                            Log.v("Order____-", "Here Outside");

                                Log.v("Order____-", "Not Completed");

                                status = d.child("Status").getValue().toString();
                                orderId = d.child("OrderId").getValue().toString();
                                Log.d("Checking_id's", "sadasdasd    " + orderId + "   " + d.child("Order_Time").getValue(Long.class));


                                if (d.child("Order_Time").getValue(Long.class) != null && !d.child("OrderId").getValue().toString().equals("")) {

                                    orderno_list.add(orderId);

                                }


                                addressString = d.child("Address").getValue().toString();



                                int number = d.child("NumberOfFoods").getValue(Integer.class);
                                String orderNumber = d.getKey();
                                orderNumberText.setText(orderNumber);


                                for (int i = 0; i < number; i++) {

                                    Log.v("Order____-", "Added");

                                    CartProductModel model = d.child(String.valueOf(i)).getValue(CartProductModel.class);
                                    list.add(model);

                                }



                        }
                    } catch (Exception e) {
                        Log.v("Errorrr", "Errorr: " + e.getMessage());
                    }
                }
                gettinglist(orderno_list);
                Log.d("List_Size", "gettinglist  " + orderno_list.size());

                if (list.size() > 0) {
                    emptyOrders.setVisibility(View.GONE);
                    ordersLayout.setVisibility(View.VISIBLE);
                } else {

                    ordersLayout.setVisibility(View.VISIBLE);
                }


            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void gettinglist(final ArrayList<String> orderno_list) {
        Log.d("List_Size", "abcdefgh  " + orderno_list.size());
        DatabaseReference getting_details = FirebaseDatabase.getInstance().getReference().child("Orders");
        getting_details.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                cancel_list.clear();
                for (DataSnapshot d : dataSnapshot.getChildren()) {


                    if (orderno_list.contains(d.getKey())) {

                        String address = d.child("Address").getValue().toString();
                        String totalCost = d.child("TotalCost").getValue().toString();
                        String orderno = d.child("OrderId").getValue().toString();
                        String status = d.child("Status").getValue().toString();
                        String numberOfFoods = String.valueOf(d.child("NumberOfFoods").getValue(Integer.class));
                        long order_time = d.child("Order_Time").getValue(Long.class);
                        int no = Integer.parseInt(numberOfFoods);

                        String detail = "";

                        for (int i = 0; i < no; i++) {
                            int quantity = d.child(String.valueOf(i)).child("quantity").getValue(Integer.class);
                            double price = Double.parseDouble(d.child(String.valueOf(i)).child("productPrice").getValue().toString());
                            double total = quantity * price;
                            String formattedValue = String.format("%.2f", total);

                            detail = detail + d.child(String.valueOf(i)).child("productName").getValue().toString() + "\nPrice : " + d.child(String.valueOf(i)).child("quantity").getValue(Integer.class) + " x " + d.child(String.valueOf(i)).child("productPrice").getValue().toString() + " = " + formattedValue +"£" + "\n\n";
                        }

                        Log.d("Checking_Details", "dadfds   " + orderno + "  " + order_time + "   " + address + " " + totalCost);


                        CancelModel cancelModel = new CancelModel(detail, totalCost, address, orderno,status, order_time);
                        cancel_list.add(cancelModel);
                    }


                }


                ordersAdapter.notifyDataSetChanged();

                Log.d("List_Size", "adasdas  " + cancel_list.size());


            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }






    private void Navigation_Drawer(){

        imageView = findViewById(R.id.menu_icon);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        View header = navigationView.getHeaderView(0);

        header_name = header.findViewById(R.id.name_header);
        header_image = header.findViewById(R.id.imageView_header);


        DatabaseReference mDatabaseForManagement = FirebaseDatabase.getInstance().getReference().child("AccountInfo").child("Users").child(mAuth.getCurrentUser().getUid());
        mDatabaseForManagement.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                UserModel userModel = dataSnapshot.getValue(UserModel.class);
                header_name.setText(userModel.getUser_name());
                Picasso.get()
                        .load(userModel.getUser_image())
                        .into(header_image);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        ImageListener();
        NavigationListener();
    }

    private void ImageListener() {
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    private void NavigationListener() {
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                int itemId = menuItem.getItemId();
                drawerLayout.closeDrawer(GravityCompat.START);

                switch (itemId) {

                    case R.id.home:
                        try {
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                        } catch (Exception e) {
                        }
                        break;

                    case R.id.order_history:

                        startActivity(new Intent(getApplicationContext(),OrderHistory.class));
                        break;


                    case R.id.share:
                        try {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("text/plain");
                            i.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
                            final String appPackageName = getPackageName();
                            String Company_Data = "Try This Jaaflong Tandori At \n" + "https://play.google.com/store/apps/details?id=" + appPackageName;
                            i.putExtra(Intent.EXTRA_TEXT, Company_Data);
                            startActivity(Intent.createChooser(i, "choose one"));
                        } catch (Exception e) {
                        }
                        break;
                    case R.id.nav_Rate:
                        Uri uri = Uri.parse("market://details?id=" + getApplicationContext().getPackageName());
                        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                                Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                                Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                        try {
                            startActivity(goToMarket);
                        } catch (ActivityNotFoundException e) {
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                        }
                        break;

                    case R.id.nav_signout:
                        mAuth.signOut();
                        Intent intent = new Intent(getApplicationContext(), LogInActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                        break;

                }


                return false;
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        CartDbHelper dbHelper  = new CartDbHelper(this);

        String item_np = String.valueOf(dbHelper.getAllItems().size());

        TextView cart_item_no =  findViewById(R.id.cart_items_number);
        if (dbHelper.getAllItems().size() >0){

            cart_item_no.setVisibility(View.VISIBLE);
            cart_item_no.setText(item_np);
        }
        else {
            cart_item_no.setVisibility(View.GONE);
        }


    }

}


