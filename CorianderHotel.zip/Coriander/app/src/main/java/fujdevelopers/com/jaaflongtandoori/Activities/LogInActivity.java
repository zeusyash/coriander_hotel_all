package fujdevelopers.com.jaaflongtandoori.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.valdesekamdem.library.mdtoast.MDToast;

import fujdevelopers.com.jaaflongtandoori.R;

public class LogInActivity extends AppCompatActivity {

    EditText emailEdit, passwordEdit;

    Button loginBtn,guestBtn;
    TextView forgetPass;

    ProgressDialog progressDialog;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);


        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);

        findViewById(R.id.register_btn_login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LogInActivity.this, SignUpActivity.class));
            }
        });

        guestBtn = findViewById(R.id.guest_btn_login);


        forgetPass = findViewById(R.id.forgetPass);
        forgetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LogInActivity.this,ForgotPasswordActivity.class));
            }
        });

        emailEdit = findViewById(R.id.email_edit_login);
        passwordEdit = findViewById(R.id.password_edit_login);

        loginBtn = findViewById(R.id.login_btn_login);

        guestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(LogInActivity.this,MainActivity.class));
                startActivity(new Intent(LogInActivity.this,GuestOrderActivity.class));
                finish();
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emailEdit.getText().toString().isEmpty() || passwordEdit.getText().toString().isEmpty()) {
                    MDToast.makeText(LogInActivity.this, "Please Fill above fields first.", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }
                if (!isEmailvalid(emailEdit.getText().toString())) {
                    MDToast.makeText(LogInActivity.this, "Email not Valid", MDToast.LENGTH_LONG, MDToast.TYPE_ERROR).show();
                    return;
                }

                progressDialog.setTitle("Logging in");
                progressDialog.setMessage("Please wait while we log you in.");
                progressDialog.show();

                mAuth.signInWithEmailAndPassword(emailEdit.getText().toString().trim(), passwordEdit.getText().toString())
                        .addOnCompleteListener(LogInActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d("LOGGING", "signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();

                                    updateUI();
                                    //updateUI(user);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w("LOGGING", "signInWithEmail:failure", task.getException());
                                    Toast.makeText(LogInActivity.this, "Authentication failed : " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                    progressDialog.dismiss();
                                    //updateUI(null);
                                }

                                // ...
                            }
                        });

            }
        });

    }

    private boolean isEmailvalid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void updateUI() {
        Log.d("LOGGING","INSIDE UPDATE UI: ");


        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("AccountType").child(mAuth.getCurrentUser().getUid());
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("LOGGING","INSIDE UPDATE UI: ON DATA CHANGE");

                if (dataSnapshot.exists()) {
                    Log.d("LOGGING","INSIDE UPDATE UI: ON DATA CHANGE: EXISTS");

                    progressDialog.dismiss();
                    String type = dataSnapshot.getValue().toString();
                    GuestDetailsStatic.Gname="";
                    GuestDetailsStatic.Gphno="";
                    GuestDetailsStatic.Gmail="";
                    GuestDetailsStatic.Gaddr="";
                    startActivity(new Intent(LogInActivity.this, MainActivity.class));
                    finish();

                }
                else{
                    Log.d("LOGGING","INSIDE UPDATE UI: ON DATA CHANGE: NOT EXISTS xx");

                    Toast.makeText(LogInActivity.this,"NOT EXISTS",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("LOGGING","INSIDE UPDATE UI: ON CANCELLED: "+databaseError.toString());


            }
        });

    }
}
